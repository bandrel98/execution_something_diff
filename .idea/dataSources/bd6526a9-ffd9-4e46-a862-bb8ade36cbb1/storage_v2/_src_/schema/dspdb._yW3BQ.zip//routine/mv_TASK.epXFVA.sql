create
    definer = weng@`10.72.1.92` procedure mv_TASK()
BEGIN
drop table if exists max_test.task_bak;
create table max_test.task_bak (
  ID varchar(100),
  CUSTOMER_ID VARCHAR(100),
  ENTITY_ID VARCHAR(100),
  `TYPE` VARCHAR(100),
  `STATUS` VARCHAR(100),
  EXECUTOR_ID VARCHAR(100),
  EXECUTOR_NAME VARCHAR(100),
  EXECUTE_TIME datetime,
  EXECUTOR_ORG VARCHAR(100),
  CREATE_ID VARCHAR(100),
  CREATE_TIME DATETIME,
  CREATOR_ORGANIZATION_ID VARCHAR(100),
  GUIDE_ORG_ID VARCHAR(100),
  CREATOR_ID VARCHAR(100),
  CREATOR_NAME VARCHAR(100)
);
-- 培育 93917
DELETE FROM dspdb.TASK WHERE STATUS in ("WAIT", "RUNNING"); # 清除任务数据
DELETE FROM dspdb.TASK_OPPORTUNITY WHERE STATUS in ("VALID"); #清除 任务 销售机会 关系 数据 
insert into max_test.task_bak#
SELECT
     '' as ID
    ,a.CUSTOMER_ID as CUSTOMER_ID
    ,a.HOUSE_ID as ENTITY_ID
    ,'FOSTER' as `TYPE`
    ,'RUNNING' as `STATUS` 
    ,a.CREATOR_ID as EXECUTOR_ID
    ,a.CREATOR_NAME as EXECUTOR_NAME
    ,SYSDATE() as EXECUTE_TIME
    ,a.CREATOR_ORGANIZATION_ID as EXECUTOR_ORG
    ,a.CREATOR_ID as CREATE_ID
    ,SYSDATE() as CREATE_TIME
    ,'' as CREATOR_ORGANIZATION_ID
    ,'' as GUIDE_ORG_ID
    ,'' as CREATOR_ID
    ,a.CREATOR_NAME as CREATOR_NAME
FROM dspdb.cust_opportunity a
WHERE -- NOT EXISTS (SELECT 1 FROM dspdb.ord_brand_order b where a.ID=b.OPPORTUNITY_ID)
 a.CREATOR_ID is not NULL
and a.CREATOR_ID <> '999999999'
and a.CREATOR_NAME is not null
and a.CREATOR_ORGANIZATION_ID is not NULL
and a.GUIDE_ID is null
and a.GUIDE_NAME is null
and a.GUIDE_ORG_ID is null
and a.DESIGNER_ID is NULL
and a.DESIGNER_NAME is null
and a.DESIGNER_ORG_ID is null
and a.MEASURE_DATE is null
and a.VALID = 1
group by a.CUSTOMER_ID
        ,a.HOUSE_ID
        ,a.CREATOR_ID
        ,a.CREATOR_ORGANIZATION_ID
        ,a.CREATOR_NAME;
        
-- 跟进 118690
INSERT INTO max_test.task_bak
SELECT
     '' as ID
    ,a.CUSTOMER_ID as CUSTOMER_ID
    ,a.HOUSE_ID as ENTITY_ID
    ,'FOLLOW' as TYPE
    ,'RUNNING' as STATUS
    ,a.GUIDE_ID as EXECUTOR_ID
    ,a.GUIDE_NAME as EXECUTOR_NAME
    ,SYSDATE() as EXECUTE_TIME
    ,a.GUIDE_ORG_ID as EXECUTOR_ORG
    ,a.CREATOR_ID as CREATE_ID
    ,SYSDATE() as CREATE_TIME
    ,a.CREATOR_ORGANIZATION_ID as CREATOR_ORGANIZATION_ID
    ,'' as GUIDE_ORG_ID
    ,'' as CREATOR_ID
    ,'' as CREATOR_NAME
FROM dspdb.cust_opportunity a
WHERE  -- NOT EXISTS (SELECT 1 FROM dspdb.ord_brand_order b where a.ID=b.OPPORTUNITY_ID)
 a.CREATOR_ID is not NULL
and a.CREATOR_NAME is not null
and a.CREATOR_ORGANIZATION_ID is not NULL
and a.GUIDE_ID is not null
and a.GUIDE_ID <> '999999999'
and a.GUIDE_NAME is not null
and a.GUIDE_ORG_ID is not null
and a.DESIGNER_ID is NULL
and a.DESIGNER_NAME is null
and a.DESIGNER_ORG_ID is null
and a.MEASURE_DATE is null
and a.VALID = 1
group by a.CUSTOMER_ID
        ,a.HOUSE_ID
        ,a.GUIDE_ID
        ,a.GUIDE_ORG_ID
        ,a.GUIDE_NAME
        ,a.CREATOR_ID
        ,a.CREATOR_ORGANIZATION_ID;
-- 测量 485
INSERT INTO max_test.task_bak
SELECT
     ''                as ID
    ,a.CUSTOMER_ID     as CUSTOMER_ID
    ,a.HOUSE_ID        as ENTITY_ID
    ,'MEASURE'         as TYPE
    ,'RUNNING'            as STATUS
    ,a.DESIGNER_ID     as EXECUTOR_ID
    ,a.DESIGNER_NAME   as EXECUTOR_NAME
    ,SYSDATE()         as EXECUTE_TIME
    ,a.DESIGNER_ORG_ID as EXECUTOR_ORG
    ,a.GUIDE_ID        as CREATE_ID
    ,SYSDATE()         as CREATE_TIME
    ,a.CREATOR_ORGANIZATION_ID as CREATOR_ORGANIZATION_ID
    ,a.GUIDE_ORG_ID as GUIDE_ORG_ID
    ,a.CREATOR_ID as CREATOR_ID
    ,'' as CREATOR_NAME
FROM dspdb.cust_opportunity a
WHERE  -- NOT EXISTS (SELECT 1 FROM dspdb.ord_brand_order b where a.ID=b.OPPORTUNITY_ID)
 a.CREATOR_ID is not NULL
and a.CREATOR_NAME is not null
and a.CREATOR_ORGANIZATION_ID is not NULL
and a.GUIDE_ID is not null
and a.GUIDE_NAME is not null
and a.GUIDE_ORG_ID is not null
and a.DESIGNER_ID is not null
and a.DESIGNER_ID <> '999999999'
and a.DESIGNER_NAME is not null
and a.DESIGNER_ORG_ID is not null
and a.MEASURE_DATE is null
and a.VALID = 1
group by a.CUSTOMER_ID
        ,a.HOUSE_ID
        ,a.DESIGNER_ID
        ,a.DESIGNER_ORG_ID
        ,a.DESIGNER_NAME
        ,a.GUIDE_ID
        ,a.GUIDE_ORG_ID
        ,a.CREATOR_ID
        ,a.CREATOR_ORGANIZATION_ID;
        
-- 新建临时表
DROP TABLE IF EXISTS max_test.task_opportunity_bak;
CREATE TABLE max_test.task_opportunity_bak (
  ID VARCHAR(100),
  CUSTOMER_ID VARCHAR(100),
  HOUSE_ID VARCHAR(100),
  `TYPE` VARCHAR(100),
  `STATUS` VARCHAR(100),
  EXECUTOR_ID VARCHAR(100),
  EXECUTOR_NAME VARCHAR(100),
  EXECUTE_TIME DATETIME,
  EXECUTOR_ORG VARCHAR(100),
  CREATE_ID VARCHAR(100),
  CREATE_TIME DATETIME,
  CREATOR_ORGANIZATION_ID VARCHAR(100),
  GUIDE_ORG_ID VARCHAR(100),
  CREATOR_ID VARCHAR(100),
  CREATOR_NAME VARCHAR(100)
);
-- 插入数据
insert into max_test.task_opportunity_bak
select
     REPLACE(UUID(),'-','') as ID
    ,a.CUSTOMER_ID
    ,a.ENTITY_ID
    ,a.TYPE
    ,a.STATUS
    ,a.EXECUTOR_ID
    ,a.EXECUTOR_NAME
    ,a.EXECUTE_TIME
    ,a.EXECUTOR_ORG
    ,a.CREATE_ID
    ,a.CREATE_TIME
    ,a.CREATOR_ORGANIZATION_ID
    ,a.GUIDE_ORG_ID
    ,a.CREATOR_ID
    ,a.CREATOR_NAME
from max_test.task_bak a;
-- 插数进目标表 
INSERT INTO dspdb.`task`
SELECT 
     a.ID
    ,a.CUSTOMER_ID
    ,a.HOUSE_ID
    ,a.TYPE
    ,a.STATUS
    ,a.EXECUTOR_ID
    ,a.EXECUTOR_NAME
    ,SYSDATE()
    ,a.EXECUTOR_ORG
    ,a.CREATE_ID
    ,SYSDATE()
    ,NULL
    ,NULL
    ,NULL
    ,NULL
    ,NULL
    ,NULL
    ,NULL
FROM max_test.task_opportunity_bak a;
-- 任务销售机会数据
-- 培育 
insert into dspdb.`task_opportunity`
select
     a.ID
    ,b.ID
    ,'VALID'
from max_test.task_opportunity_bak a
inner join dspdb.`cust_opportunity` b
on  b.CREATOR_ID = a.EXECUTOR_ID
and b.CREATOR_ORGANIZATION_ID = a.EXECUTOR_ORG
and b.CREATOR_NAME = a.EXECUTOR_NAME
and b.GUIDE_ID IS NULL
and b.GUIDE_NAME IS NULL
and b.GUIDE_ORG_ID IS NULL
and b.DESIGNER_ID IS NULL
and b.DESIGNER_NAME IS NULL
and b.DESIGNER_ORG_ID IS NULL
and b.MEASURE_DATE IS NULL
and b.VALID = 1
and b.CUSTOMER_ID = a.CUSTOMER_ID
and b.HOUSE_ID = a.HOUSE_ID
where a.TYPE='FOSTER';
 
-- 跟进
insert into dspdb.`task_opportunity`
select
     a.ID
    ,b.ID
    ,'VALID'
from max_test.task_opportunity_bak a
inner join dspdb.`cust_opportunity` b
on  b.CREATOR_ID = a.CREATE_ID
AND b.CREATOR_ORGANIZATION_ID = a.CREATOR_ORGANIZATION_ID
AND b.CREATOR_NAME IS NOT NULL
AND b.GUIDE_ID = a.EXECUTOR_ID
AND b.GUIDE_NAME = a.EXECUTOR_NAME
AND b.GUIDE_ORG_ID = a.EXECUTOR_ORG
AND b.DESIGNER_ID IS NULL
AND b.DESIGNER_NAME IS NULL
AND b.DESIGNER_ORG_ID IS NULL
AND b.VALID = 1
AND b.CUSTOMER_ID = a.CUSTOMER_ID
AND b.HOUSE_ID = a.HOUSE_ID
where a.TYPE='FOLLOW';
    
-- 测量
insert into dspdb.`task_opportunity`
SELECT
     a.ID
    ,b.ID
    ,'VALID'
FROM max_test.task_opportunity_bak a
INNER JOIN dspdb.`cust_opportunity` b
on  b.CREATOR_ID = a.CREATOR_ID
AND b.CREATOR_ORGANIZATION_ID = a.CREATOR_ORGANIZATION_ID
AND b.CREATOR_NAME IS NOT NULL
AND b.GUIDE_ID = a.CREATE_ID
AND b.GUIDE_NAME IS NOT NULL
AND b.GUIDE_ORG_ID = a.GUIDE_ORG_ID
AND b.DESIGNER_ID = a. EXECUTOR_ID
AND b.DESIGNER_NAME = a. EXECUTOR_NAME
AND b.DESIGNER_ORG_ID = a. EXECUTOR_ORG
AND b.VALID = 1
AND b.CUSTOMER_ID = a.CUSTOMER_ID
AND b.HOUSE_ID = a.HOUSE_ID
where a.TYPE='MEASURE';
    END;

