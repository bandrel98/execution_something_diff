create
    definer = root@`%` procedure modify_finance(IN cust_name varchar(255), IN cust_mob varchar(255),
                                                IN amount varchar(255), IN operate varchar(20))
BEGIN  
  
DECLARE old_amount varchar(255);
DECLARE D_amount VARCHAR(255);
DECLARE valid_amount VARCHAR(255);
select t1.DECREASE_FROZEN ,t2.balance_1,t1.BALANCE into old_amount ,D_amount,valid_amount
FROM dspdb.finance_fund_account t1
LEFT JOIN test.`finance_fund_account20190227` t2 ON t1.ID=t2.ID
WHERE t2.`mobile`= cust_mob AND t2.`name`=cust_name
;

if operate='查询' then
 SELECT 
 '当前信息' AS  时点
,t2.`NAME` AS 姓名
,t2.MOBILE AS 手机号
,t1.BALANCE AS 账户余额
,t1.BALANCE - t1.DECREASE_FROZEN AS 可用金额
,t1.DECREASE_FROZEN AS 冻结金额
,t1.LAST_UPDATE_TIME AS 最后更新时间
FROM dspdb.finance_fund_account t1
LEFT JOIN test.`finance_fund_account20190227` t2 ON t1.ID=t2.ID
WHERE t2.`mobile`= cust_mob AND t2.`name`=cust_name
;

ELSEIF
   operate='解冻' and old_amount>=amount  then 
UPDATE dspdb.`finance_fund_account` ffa
INNER JOIN test.`finance_fund_account20190227` t ON ffa.`ID` = t.ID 
SET ffa.DECREASE_FROZEN = ffa.DECREASE_FROZEN - amount
WHERE t.`mobile`= cust_mob AND t.`name`=cust_name
;
  
 SELECT 
 '解冻前' AS  时点
,t2.`NAME` AS 姓名
,t2.MOBILE AS 手机号
,t1.BALANCE AS 账户余额
,t1.BALANCE - old_amount AS 可用金额
,old_amount AS 冻结金额
,t1.LAST_UPDATE_TIME AS 最后更新时间
FROM dspdb.finance_fund_account t1
LEFT JOIN test.`finance_fund_account20190227` t2 ON t1.ID=t2.ID
WHERE t2.`mobile`= cust_mob AND t2.`name`=cust_name
union all 
SELECT 
 '解冻后' as  时点
,t2.`NAME` AS 姓名
,t2.MOBILE AS 手机号
,t1.BALANCE AS 账户余额
,t1.BALANCE - t1.DECREASE_FROZEN AS 可用金额
,t1.DECREASE_FROZEN AS 冻结金额
,t1.LAST_UPDATE_TIME AS 最后更新时间
FROM dspdb.finance_fund_account t1
LEFT JOIN test.`finance_fund_account20190227` t2 ON t1.ID=t2.ID
WHERE t2.`mobile`= cust_mob AND t2.`name`=cust_name
;

ELSEIF
   operate='冻结' and amount<=valid_amount-old_amount then 
UPDATE dspdb.`finance_fund_account` ffa
INNER JOIN test.`finance_fund_account20190227` t ON ffa.`ID` = t.ID 
SET ffa.DECREASE_FROZEN = ffa.DECREASE_FROZEN + amount
WHERE t.`mobile`= cust_mob AND t.`name`=cust_name
;
  
 SELECT 
 '冻结前' AS  时点
,t2.`NAME` AS 姓名
,t2.MOBILE AS 手机号
,t1.BALANCE AS 账户余额
,t1.BALANCE - old_amount AS 可用金额
,old_amount AS 冻结金额
,t1.LAST_UPDATE_TIME AS 最后更新时间
FROM dspdb.finance_fund_account t1
LEFT JOIN test.`finance_fund_account20190227` t2 ON t1.ID=t2.ID
WHERE t2.`mobile`= cust_mob AND t2.`name`=cust_name
union all 
SELECT 
 '冻结后' as  时点
,t2.`NAME` AS 姓名
,t2.MOBILE AS 手机号
,t1.BALANCE AS 账户余额
,t1.BALANCE - t1.DECREASE_FROZEN AS 可用金额
,t1.DECREASE_FROZEN AS 冻结金额
,t1.LAST_UPDATE_TIME AS 最后更新时间
FROM dspdb.finance_fund_account t1
LEFT JOIN test.`finance_fund_account20190227` t2 ON t1.ID=t2.ID
WHERE t2.`mobile`= cust_mob AND t2.`name`=cust_name
;
  
end  if ; 
END;

