create
    definer = hemp@`%` procedure mv_REPOSITORY_SUBORDER()
BEGIN
TRUNCATE TABLE dspdb.`REPOSITORY_SUBORDER`;
-- 正单
INSERT INTO dspdb.`REPOSITORY_SUBORDER`
SELECT
   REPLACE(UUID(),'-','') AS ID                          -- 主键
  ,b.ID AS REPOSITORY_ID                                 -- 仓库id
  ,NULL AS REPOSITORY_SENDCAR_ID                         -- 仓库派车id
  ,a.ORDER_ID AS ORDER_ID                                -- 子单ID
  ,a.ORDER_NUM AS ORDER_NO                               -- 子单单号
  ,h.YUN_NUM AS CLOUD_ORDER_NO                           -- 云单号(司米独有)
  ,h.IGT_NUM AS IGT_ORDER_NO                             -- IGT单号(司米独有)
  ,c.DELIVERY_TIME AS DELIVERY_DATE                      -- 送货日期
  ,d.SENG_OUT_DATE AS FACTORY_DELIVER_DATE               -- 工厂发货日期
  ,d.ARRIVAL_DATE AS ARRIVE_DATE                         -- 到货日期
  ,CASE WHEN d.ARRIVAL_STATUS='部分到货' THEN 0
        ELSE d.ARRIVAL_COUNT
        END AS SHOULD_PACKAGE_QTY                        -- 应到包数
  ,d.ARRIVAL_COUNT AS REAL_PACKAGE_QTY                   -- 实到包数
  ,NULL AS PRODUCE_ORDER_NO                              -- 生产单号(米兰纳独有)
  ,0 AS DOOR_LEAF_QTY                                    -- 门扇包数(米兰纳独有)
  ,0 AS DOOR_POCKET_QTY                                  -- 门套包数(米兰纳独有)
  ,0 AS DECORATE_MATERIAL_QTY                            -- 装饰材料包数(米兰纳独有)
  ,0 AS HARDWARE_QTY                                     -- 五金包数(米兰纳独有)
  ,CASE WHEN d.ARRIVAL_STATUS='已到货' THEN 'ALL_ARRIVE'
        WHEN d.ARRIVAL_STATUS='部分到货' THEN 'ALL_ARRIVE'
        ELSE 'NOT_ARRIVE'
        END AS ARRIVE_STATUS                             -- 到货状态:未到货,已到货
  ,CASE WHEN d.ARRIVAL_STATUS='已到货' THEN 'REPOSITORY_IN'
        WHEN d.ARRIVAL_STATUS='部分到货' THEN 'REPOSITORY_IN'
        ELSE 'REPOSITORY_NOT_IN'
        END AS INVENTORY_STATUS                          -- 已入库,未入库
  ,IFNULL(a.CREATION_DATE,SYSDATE()) AS GMT_CREATE       -- 创建时间
  ,IFNULL(e.new_id,'999999999') AS CREATOR_ID            -- 创建人
  ,IFNULL(a.LAST_UPDATE_DATE,SYSDATE()) AS GMT_MODIFIED  -- 更新时间
  ,IFNULL(f.new_id,'999999999') AS MODIFIED_USER_ID      -- 更新人
FROM sm_zy.sg_order a
JOIN max_test.REPOSITORY_bak b ON a.OPTY_ID=b.OPPORTUNITY_ID
LEFT JOIN sm_zy.dms_plan_info c ON a.OPTY_ID=c.BILL_ID
LEFT JOIN max_test.sg_arrival_ext_bak d ON a.OPTY_ID=d.OPPORTUNITY_ID
LEFT JOIN max_test.map_emp e ON a.CREATED_BY=e.old_id
LEFT JOIN max_test.map_emp f ON a.LAST_UPDATED_BY=f.old_id
-- JOIN sm_zy.dms_order_ext g ON a.ORDER_ID=g.ORDER_ID
LEFT JOIN sm_zy.dms_opportunities_ext h ON a.OPTY_ID=h.OPPORTUNITY_ID
WHERE SUBSTR(a.order_num,1,1)='C';
-- 增补单
INSERT INTO dspdb.`REPOSITORY_SUBORDER`
SELECT
   REPLACE(UUID(),'-','') AS ID                          -- 主键
  ,b.ID AS REPOSITORY_ID                                 -- 仓库id
  ,NULL AS REPOSITORY_SENDCAR_ID                         -- 仓库派车id
  ,a.ORDER_ID AS ORDER_ID                                -- 子单ID
  ,a.ORDER_NUM AS ORDER_NO                               -- 子单单号
  ,h.YUN_NUM AS CLOUD_ORDER_NO                           -- 云单号(司米独有)
  ,h.IGT_NUM AS IGT_ORDER_NO                             -- IGT单号(司米独有)
  ,c.DELIVERY_TIME AS DELIVERY_DATE                      -- 送货日期
  ,d.SENG_OUT_DATE AS FACTORY_DELIVER_DATE               -- 工厂发货日期
  ,d.ARRIVAL_DATE AS ARRIVE_DATE                         -- 到货日期
  ,CASE WHEN d.ARRIVAL_STATUS='部分到货' THEN 0
        ELSE d.ARRIVAL_COUNT
        END AS SHOULD_PACKAGE_QTY                        -- 应到包数
  ,d.ARRIVAL_COUNT AS REAL_PACKAGE_QTY                   -- 实到包数
  ,NULL AS PRODUCE_ORDER_NO                              -- 生产单号(米兰纳独有)
  ,0 AS DOOR_LEAF_QTY                                    -- 门扇包数(米兰纳独有)
  ,0 AS DOOR_POCKET_QTY                                  -- 门套包数(米兰纳独有)
  ,0 AS DECORATE_MATERIAL_QTY                            -- 装饰材料包数(米兰纳独有)
  ,0 AS HARDWARE_QTY                                     -- 五金包数(米兰纳独有)
  ,CASE WHEN d.ARRIVAL_STATUS='已到货' THEN 'ALL_ARRIVE'
        WHEN d.ARRIVAL_STATUS='部分到货' THEN 'ALL_ARRIVE'
        ELSE 'NOT_ARRIVE'
        END AS ARRIVE_STATUS                             -- 到货状态:未到货,已到货
  ,CASE WHEN d.ARRIVAL_STATUS='已到货' THEN 'REPOSITORY_IN'
        WHEN d.ARRIVAL_STATUS='部分到货' THEN 'REPOSITORY_IN'
        ELSE 'REPOSITORY_NOT_IN'
        END AS INVENTORY_STATUS                          -- 已入库,未入库
  ,IFNULL(a.CREATION_DATE,SYSDATE()) AS GMT_CREATE       -- 创建时间
  ,IFNULL(e.new_id,'999999999') AS CREATOR_ID            -- 创建人
  ,IFNULL(a.LAST_UPDATE_DATE,SYSDATE()) AS GMT_MODIFIED  -- 更新时间
  ,IFNULL(f.new_id,'999999999') AS MODIFIED_USER_ID      -- 更新人
FROM sm_zy.sg_order a
JOIN max_test.REPOSITORY_bak b ON a.OPTY_ID=b.OPPORTUNITY_ID
LEFT JOIN sm_zy.dms_plan_info c ON a.OPTY_ID=c.BILL_ID
LEFT JOIN max_test.sg_arrival_ext_bak d ON a.OPTY_ID=d.OPPORTUNITY_ID
LEFT JOIN max_test.map_emp e ON a.CREATED_BY=e.old_id
LEFT JOIN max_test.map_emp f ON a.LAST_UPDATED_BY=f.old_id
-- JOIN sm_zy.dms_order_ext g ON a.ORDER_ID=g.ORDER_ID
LEFT JOIN sm_zy.dms_opportunities_ext h ON a.OPTY_ID=h.OPPORTUNITY_ID
WHERE SUBSTR(a.order_num,1,3)='ZBC';
-- 删除中间表
-- drop table if exists max_test.REPOSITORY_bak;
-- DROP TABLE IF EXISTS max_test.sg_arrival_ext_bak;
/*
开始云单号取错表了，所以后续通过语句更新云单号字段数据
UPDATE  dspdb.`REPOSITORY_SUBORDER` t1 JOIN (
SELECT t.id,t2.`YUN_NUM` FROM dspdb.ord_sub_order  t JOIN sm_zy.`dms_opportunities_ext` t2
ON t.brand_order_id=t2.`OPPORTUNITY_ID`)t
ON t1.`ORDER_ID`=t.ID
SET t1.`CLOUD_ORDER_NO`=t.YUN_NUM;
*/
    END;

