create
    definer = hemp@`%` procedure mv_PROD_MATERIAL_SCHMIDT()
BEGIN
-- DROP TABLE IF EXISTS max_test.PROD_MATERIAL_SCHMIDT_bak;
-- 司米物料20170508
-- CREATE TABLE max_test.PROD_MATERIAL_SCHMIDT_bak
truncate table max_test.PROD_MATERIAL_SCHMIDT_bak;
insert into max_test.PROD_MATERIAL_SCHMIDT_bak
SELECT
     '' AS ID
    ,'20170508' AS PRICE_VERSION
    ,a.CATEGORY AS CATEGORY
    ,a.CATEGORY_PATH AS CATEGORY_PATH
    ,a.CODE AS CODE
    ,a.NAME AS NAME
    ,a.MATERIAL AS MATERIAL
    ,a.PRICE AS PRICE
    ,a.WIDTH AS WIDTH
    ,a.DEPTH AS DEPTH
    ,a.HEIGHT AS HEIGHT
    ,a.UNIT AS UNIT
    ,CASE WHEN a.OUT_STATUS='常规外协' THEN 'R_ASSIST'
          WHEN a.OUT_STATUS='T类外协'  THEN 'T_ASSIST'
          WHEN a.OUT_STATUS='非外协'   THEN 'NON_ASSIST'
     END AS OUT_STATUS
    ,CASE WHEN a.ORIGIN='北京' THEN 'BEIJING'
          WHEN a.ORIGIN='广州' THEN 'GUANGZHOU'
     END AS ORIGIN
    ,1 AS VALID
FROM max_test.sm0508 a;
-- 司米物料20170508补充
INSERT INTO max_test.PROD_MATERIAL_SCHMIDT_bak
SELECT
     '' AS ID
    ,'20170508' AS PRICE_VERSION
    ,a.CATEGORY AS CATEGORY
    ,a.CATEGORY_PATH AS CATEGORY_PATH
    ,a.CODE AS CODE
    ,a.NAME AS NAME
    ,a.MATERIAL AS MATERIAL
    ,a.PRICE AS PRICE
    ,a.WIDTH AS WIDTH
    ,a.DEPTH AS DEPTH
    ,a.HEIGHT AS HEIGHT
    ,a.UNIT AS UNIT
    ,CASE WHEN a.OUT_STATUS='常规外协' THEN 'R_ASSIST'
          WHEN a.OUT_STATUS='T类外协'  THEN 'T_ASSIST'
          WHEN a.OUT_STATUS='非外协'   THEN 'NON_ASSIST'
     END AS OUT_STATUS
    ,CASE WHEN a.ORIGIN='北京' THEN 'BEIJING'
          WHEN a.ORIGIN='广州' THEN 'GUANGZHOU'
     END AS ORIGIN
    ,1 AS VALID
FROM max_test.sm0401 a
WHERE NOT EXISTS
(SELECT 1 FROM max_test.sm0508 b WHERE a.CODE=b.CODE AND a.MATERIAL=b.MATERIAL);
-- 复制司米物料20171201
INSERT INTO max_test.PROD_MATERIAL_SCHMIDT_bak
SELECT
     '' AS ID
    ,'20171201' AS PRICE_VERSION
    ,a.CATEGORY AS CATEGORY
    ,a.CATEGORY_PATH AS CATEGORY_PATH
    ,a.CODE AS CODE
    ,a.NAME AS NAME
    ,a.MATERIAL AS MATERIAL
    ,a.PRICE AS PRICE
    ,a.WIDTH AS WIDTH
    ,a.DEPTH AS DEPTH
    ,a.HEIGHT AS HEIGHT
    ,a.UNIT AS UNIT
    ,CASE WHEN a.OUT_STATUS='常规外协' THEN 'R_ASSIST'
          WHEN a.OUT_STATUS='T类外协'  THEN 'T_ASSIST'
          WHEN a.OUT_STATUS='非外协'   THEN 'NON_ASSIST'
     END AS OUT_STATUS
    ,CASE WHEN a.ORIGIN='北京' THEN 'BEIJING'
          WHEN a.ORIGIN='广州' THEN 'GUANGZHOU'
     END AS ORIGIN
    ,1 AS VALID
FROM max_test.sm0508 a;
-- 复制司米物料20171201
INSERT INTO max_test.PROD_MATERIAL_SCHMIDT_bak
SELECT
     '' AS ID
    ,'20171201' AS PRICE_VERSION
    ,a.CATEGORY AS CATEGORY
    ,a.CATEGORY_PATH AS CATEGORY_PATH
    ,a.CODE AS CODE
    ,a.NAME AS NAME
    ,a.MATERIAL AS MATERIAL
    ,a.PRICE AS PRICE
    ,a.WIDTH AS WIDTH
    ,a.DEPTH AS DEPTH
    ,a.HEIGHT AS HEIGHT
    ,a.UNIT AS UNIT
    ,CASE WHEN a.OUT_STATUS='常规外协' THEN 'R_ASSIST'
          WHEN a.OUT_STATUS='T类外协'  THEN 'T_ASSIST'
          WHEN a.OUT_STATUS='非外协'   THEN 'NON_ASSIST'
     END AS OUT_STATUS
    ,CASE WHEN a.ORIGIN='北京' THEN 'BEIJING'
          WHEN a.ORIGIN='广州' THEN 'GUANGZHOU'
     END AS ORIGIN
    ,1 AS VALID
FROM max_test.sm0401 a
WHERE NOT EXISTS
(SELECT 1 FROM max_test.sm0508 b WHERE a.CODE=b.CODE AND a.MATERIAL=b.MATERIAL);
-- 司米物料20180401
INSERT INTO max_test.PROD_MATERIAL_SCHMIDT_bak
SELECT
     '' AS ID
    ,'20180401' AS PRICE_VERSION
    ,a.CATEGORY AS CATEGORY
    ,a.CATEGORY_PATH AS CATEGORY_PATH
    ,a.CODE AS CODE
    ,a.NAME AS NAME
    ,a.MATERIAL AS MATERIAL
    ,a.PRICE AS PRICE
    ,a.WIDTH AS WIDTH
    ,a.DEPTH AS DEPTH
    ,a.HEIGHT AS HEIGHT
    ,a.UNIT AS UNIT
    ,CASE WHEN a.OUT_STATUS='常规外协' THEN 'R_ASSIST'
          WHEN a.OUT_STATUS='T类外协'  THEN 'T_ASSIST'
          WHEN a.OUT_STATUS='非外协'   THEN 'NON_ASSIST'
     END AS OUT_STATUS
    ,CASE WHEN a.ORIGIN='北京' THEN 'BEIJING'
          WHEN a.ORIGIN='广州' THEN 'GUANGZHOU'
     END AS ORIGIN
    ,1 AS VALID
FROM max_test.sm0401 a;
-- 司米物料20180401补充
INSERT INTO max_test.PROD_MATERIAL_SCHMIDT_bak
SELECT
     '' AS ID
    ,'20180401' AS PRICE_VERSION
    ,a.CATEGORY AS CATEGORY
    ,a.CATEGORY_PATH AS CATEGORY_PATH
    ,a.CODE AS CODE
    ,a.NAME AS NAME
    ,a.MATERIAL AS MATERIAL
    ,a.PRICE AS PRICE
    ,a.WIDTH AS WIDTH
    ,a.DEPTH AS DEPTH
    ,a.HEIGHT AS HEIGHT
    ,a.UNIT AS UNIT
    ,CASE WHEN a.OUT_STATUS='常规外协' THEN 'R_ASSIST'
          WHEN a.OUT_STATUS='T类外协'  THEN 'T_ASSIST'
          WHEN a.OUT_STATUS='非外协'   THEN 'NON_ASSIST'
     END AS OUT_STATUS
    ,CASE WHEN a.ORIGIN='北京' THEN 'BEIJING'
          WHEN a.ORIGIN='广州' THEN 'GUANGZHOU'
     END AS ORIGIN
    ,0 AS VALID
FROM max_test.sm0508 a
WHERE NOT EXISTS
(SELECT 1 FROM max_test.sm0401 b WHERE a.CODE=b.CODE AND a.MATERIAL=b.MATERIAL);
-- 插数进目标表
TRUNCATE TABLE dspdb.PROD_MATERIAL_SCHMIDT;
INSERT INTO dspdb.PROD_MATERIAL_SCHMIDT
SELECT
     REPLACE(UUID(),'-','')                   -- 主键ID
    ,a.PRICE_VERSION                          -- 价格版本
    ,a.CATEGORY                               -- 物料分类
    ,a.CATEGORY_PATH                          -- 物料分类寻址
    ,a.CODE                                   -- 物料编码
    ,a.NAME                                   -- 物料名称
    ,a.MATERIAL                               -- 物料材质
    ,a.PRICE                                  -- 价格
    ,a.WIDTH                                  -- 宽
    ,a.DEPTH                                  -- 深
    ,a.HEIGHT                                 -- 高
    ,a.UNIT                                   -- 单位
    ,a.OUT_STATUS                             -- 常规外协/T类外协/非外协
    ,a.ORIGIN                                 -- 产地
    ,a.VALID                                  -- 是否有效
    ,(@i:=@i+1) AS SORTED                     -- 排序
    ,'999999999' AS CREATOR                   -- 创建人
    ,SYSDATE() AS CREATE_TIME                 -- 创建时间
    ,'999999999' AS LAST_UPDATE_PERSON        -- 最近更新人
    ,SYSDATE() AS LAST_UPDATE_TIME            -- 更新时间
FROM max_test.PROD_MATERIAL_SCHMIDT_bak a,(SELECT @i:=0) AS it;
-- 删除中间表
-- DROP TABLE IF EXISTS max_test.PROD_MATERIAL_SCHMIDT_bak;
    END;

