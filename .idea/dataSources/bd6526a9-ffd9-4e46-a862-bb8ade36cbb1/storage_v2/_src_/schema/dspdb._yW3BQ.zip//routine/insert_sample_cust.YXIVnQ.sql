create
    definer = hemp@`10.10.0.125` procedure insert_sample_cust()
BEGIN
 
DECLARE done INT DEFAULT 0; 
DECLARE custId VARCHAR(36);
DECLARE custName VARCHAR(100);
DECLARE custMobile VARCHAR(12) ;
DECLARE creatorId VARCHAR(36) ;
DECLARE creatorName VARCHAR(30) ;
DECLARE creatorOrgId VARCHAR(36) ;
DECLARE houseArea VARCHAR(100) ;
DECLARE houseAddr VARCHAR(100) ;


DECLARE houseId VARCHAR(36) ;

#获取需要建上样客户的游标
DECLARE add_samplecust CURSOR FOR 

  SELECT  de.ID ORG_ID, IFNULL(od.NAME,'人员未明') EMP_NAME,  IFNULL(od.ID,'999999999')  EMP_ID,
					CONCAT(CONCAT('1880000',ROUND(ROUND(RAND(),4)*10000)) ,'Y') AS MOBILE,
IFNULL(sd.VALUE,'BEIJING.UNKNOWN') AS AREA, IFNULL(de.ADDR,'同济南路嘉捷企业汇') ADDR

   FROM
      DEALER_ORGANIZATION de 
  LEFT JOIN (
      SELECT  deo.ORG_ID ORG_ID ,MAX(deo.EMP_ID) EMP_ID FROM 
      DEALER_EMPLOYEE_ORGANIZATION deo 
      GROUP BY  deo.ORG_ID
      )t
  ON de.ID = t.ORG_ID
  LEFT JOIN DEALER_EMPLOYEE od
  ON t.EMP_ID = od.ID
LEFT JOIN (SELECT * FROM SYS_DICT WHERE TYPE ='REGION' AND PARENT='BEIJING')sd
ON de.AREA = sd.LABEL
WHERE (
    de.SOGAL_CODE IS NOT NULL
    OR de.SCHMIDT_CODE IS NOT NULL
    OR de.MILANA_CODE IS NOT NULL
  ) ;
  
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

#打开游标
OPEN add_samplecust;
#开始循环
REPEAT
#拿到列的数据
FETCH add_samplecust INTO creatorOrgId, creatorName, creatorId,custMobile,houseArea,houseAddr;
#进行数据操作
IF NOT done THEN #防止重复数据

#一、插入客户表
    #生成任务的uuid
    SELECT REPLACE(UUID(), '-', '') INTO custId; 
    INSERT INTO CUSTOMER
        (ID, NAME, MOBILE, GENDER, AGE_RANGE,
           CREATOR_ID, CREATOR_NAME, CREATOR_ORGANIZATION_ID, TIME_CREATED,
          STAGE, SOURCE,  DEALER_CODE, SECOND_SOURCE, THIRD_SOURCE,
           LEVEL,SAMPLED)
     VALUES(custId,'上样单客户',custMobile,'FEMALE',NULL,creatorId,creatorName,creatorOrgId,NOW(),
            'POTENTIAL','ZRKL','010','ZRKL.NEW_CUSTOMER',NULL,'AA',1);
    SELECT REPLACE(UUID(), '-', '') INTO houseId; 
    INSERT INTO CUST_HOUSE(ID, CUSTOMER_ID, INTENTION, CREATOR_ID,
        CREATOR_NAME, TIME_CREATED, CITY, AREA, ADDR, DEALER_CODE,
        SOURCE, SECOND_SOURCE, CREATOR_ORGANIZATION_ID) 
    VALUES(houseId,custId,'BEDROOM,BEDSIDE,TVSTAND,TATAMI',creatorId,creatorName,NOW(),'BEIJING',houseArea,
        houseAddr,'010','ZRKL','ZRKL.NEW_CUSTOMER',creatorOrgId);


    INSERT INTO DEALER_SAMPLE_CUST(SHOP_ID, CUSTOMER_ID) 
    VALUES(creatorOrgId,custId);

  END IF;
  #拿到游标结束标识，结束本次
  UNTIL done END REPEAT;
  #关闭游标
  CLOSE add_samplecust;
END;

