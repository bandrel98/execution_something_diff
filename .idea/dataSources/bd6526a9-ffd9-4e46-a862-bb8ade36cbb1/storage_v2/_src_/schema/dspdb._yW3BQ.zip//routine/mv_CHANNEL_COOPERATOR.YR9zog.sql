create
    definer = weng@`%` procedure mv_CHANNEL_COOPERATOR()
BEGIN
-- 合作方会员等级映射表
DROP TABLE IF EXISTS max_test.channal_level_ys;
CREATE TABLE max_test.`channal_level_ys` (
  `OLD_ID` VARCHAR(50) NOT NULL COMMENT '旧ID',
  `NEW_ID` VARCHAR(50) NOT NULL COMMENT '新ID',
  PRIMARY KEY (`OLD_ID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8 COMMENT='会员等级映射表';
INSERT INTO max_test.`channal_level_ys` VALUES ('ff8080815a94aa57015aa2d460230805','ff8080815a94aa57015aa2d460230805');
INSERT INTO max_test.`channal_level_ys` VALUES ('ff8080815a94aa57015aa2d560810806','ff8080815a94aa57015aa2d560810806');
INSERT INTO max_test.`channal_level_ys` VALUES ('ff8080815a94aa57015aa2d86716080f','ff8080815a94aa57015aa2d86716080f');
INSERT INTO max_test.`channal_level_ys` VALUES ('0000000058b8578d0158b94aa00f0017','ff8080815a94aa57015aa2d460230805');
INSERT INTO max_test.`channal_level_ys` VALUES ('0000000058b8578d0158b94c4da70018','ff8080815a94aa57015aa2d460230805');
INSERT INTO max_test.`channal_level_ys` VALUES ('0000000058d989b20158dc01ecd40003','ff8080815a94aa57015aa2d560810806');
INSERT INTO max_test.`channal_level_ys` VALUES ('0000000058f16fcc0158f1ecf8bf001f','ff8080815a94aa57015aa2d460230805');
INSERT INTO max_test.`channal_level_ys` VALUES ('8a53b78558f1106b0158f22fc95d0003','ff8080815a94aa57015aa2d460230805');
INSERT INTO max_test.`channal_level_ys` VALUES ('8a94a1cb5621229d015621ad09a8000d','ff8080815a94aa57015aa2d86716080f');
INSERT INTO max_test.`channal_level_ys` VALUES ('8a94a1cb5643a4430156440bfb4c0003','ff8080815a94aa57015aa2d460230805');
/*
-- 合作方手机号重复数据提取语句
SELECT * FROM dspdb.`CHANNEL_COOPERATOR` 
WHERE mobile IN (SELECT mobile FROM dspdb.`CHANNEL_COOPERATOR` GROUP BY mobile HAVING COUNT(1)>1)
ORDER BY mobile;
-- 索引
CREATE INDEX index_mobile on dspdb.CHANNEL_COOPERATOR(mobile);
CREATE INDEX index_new_phone on max_test.MAP_CUSTOMER(new_phone);
-- 中间表（目前用不上）
DROP TABLE IF EXISTS max_test.map_customer_id;
CREATE TABLE max_test.map_customer_id
SELECT 
   a.mobile AS mobile
  ,a.id AS id
  ,b.new_id AS customer_id
FROM dspdb.CHANNEL_COOPERATOR a
LEFT JOIN max_test.MAP_CUSTOMER b ON a.mobile=b.NEW_PHONE AND b.valid='1'
WHERE a.type='CUSTOMER';
*/
-- 索菲亚
-- DROP TABLE IF EXISTS max_test.CHANNEL_COOPERATOR;
-- CREATE TABLE max_test.CHANNEL_COOPERATOR
TRUNCATE TABLE max_test.CHANNEL_COOPERATOR;
INSERT INTO max_test.CHANNEL_COOPERATOR
  SELECT
  a.FILED_ID AS ID,                                              -- 合作方id
--  T1.CUSTOMER_ID AS CUSTOMER_ID,                                 -- 老客户ID
  NULL AS CUSTOMER_ID,
  a.NOTE AS COMMENTS,                                            -- 备注
  CASE WHEN a.FILE_TYPE='1' THEN 'DESIGNER'
       WHEN a.FILE_TYPE='2' THEN 'COMPANY'
       WHEN a.FILE_TYPE='3' THEN 'CUSTOMER'
       WHEN a.FILE_TYPE='4' THEN 'FOREMAN'
       WHEN a.FILE_TYPE='5' THEN 'CUSTOMER'
       WHEN a.FILE_TYPE='6' THEN 'BRAND'
       WHEN a.FILE_TYPE='7' THEN 'DIFFERENT'
       WHEN a.FILE_TYPE='8' THEN 'TEAM'
       WHEN a.FILE_TYPE='9' THEN 'RESIDENTIAL'
       WHEN a.FILE_TYPE='10' THEN 'CUSTOMER'
  ELSE a.FILE_TYPE
  END AS TYPE,                                                   -- 合作方类型
  a.COOPERATOR_NAME AS NAME,                                     -- 合作方名称
  RTRIM(REPLACE(a.TEL,'-','')) AS MOBILE,                        -- 手机号
  a.ACCOUNT_BANK AS BANK,                                        -- 开户银行
   bank.DICTNAME AS BANK1,
  a.BRANCH_BANK AS BRANCH,                                       -- 支行名称
  a.ACCOUNT AS ACCOUNT,                                          -- 银行账户
  a.ACCOUNT_NAME AS ACCOUNT_NAME,                                -- 账户名称
  a.ADDRESS AS ADDR,                                             -- 地址（街道、园区、写字楼）
  n.new_id AS LEVEL_ID,                                          -- 级别
  a.WINDOW AS GUARDIAN_ID,                                       -- 维护人id
  IFNULL(guardian.new_id,'999999999') AS  GUARDIAN_ID1,          -- 维护人id
  b.NAME AS GUARDIAN_NAME,                                       -- 维护人姓名
  CASE WHEN a.STATUS='1' AND a.FILE_TYPE NOT IN ('3','5','10') THEN 'APPROVING'
       WHEN a.STATUS='1' AND a.FILE_TYPE     IN ('3','5','10') THEN 'PASSED'
       WHEN a.STATUS='2' AND a.FILE_TYPE NOT IN ('3','5','10') THEN 'APPROVING'
       WHEN a.STATUS='2' AND a.FILE_TYPE     IN ('3','5','10') THEN 'PASSED'
       WHEN a.STATUS='3' AND a.FILE_TYPE NOT IN ('3','5','10') THEN 'SENDBACK'
       WHEN a.STATUS='3' AND a.FILE_TYPE     IN ('3','5','10') THEN 'PASSED'
       WHEN a.STATUS='4' THEN 'PASSED'
       END AS STATUS,                                            -- 审批状态dict
  a.CREATE_BY AS CREATOR_ID,                                     -- 创建人ID
  IFNULL(creater.new_id,'999999999') AS CREATOR_ID1,
  IFNULL(a.CREATE_TIME,SYSDATE()) AS TIME_CREATED,               -- 创建时间
  a.LAST_UPDATE_BY AS LAST_UPDATED_BY,                           -- 最后更新操作人ID
  IFNULL(laster.new_id,'999999999') AS LAST_UPDATED_BY1,         -- 最后更新操作人ID
  a.LAST_UPDATE_TIME AS LAST_UPDATE_TIME,                        -- 最后更新时间
  IFNULL(m.new_id,'999999999') AS CREATOR_ORG_ID,                -- 创建人所属门店ID
  m.new_name AS CREATOR_ORG_NAME,                                -- 创建人所属门店名称
  '010',                                                         -- 经销商ID
  IFNULL(a.CREDITS,'') AS INTEGRAL,                              -- 积分余额
  IFNULL(g.BAK,'') AS INTEGRAL_FROZEN,                           -- 冻结积分
  IFNULL(i.BAK,'') AS INTEGRAL_TOTAL,                            -- 累计获得积分（只增不减）
  IFNULL(k.BAK,'') AS INTEGRAL_CONSUMED,                         -- 累计消费积分（只增不减）
  a.DECORATE_COMPANY AS BELONG_COMPANY,                          -- 所属装饰公司
  a.LINK_TEL AS COMPANY_TEL,                                     -- 公司电话
  a.START_TIME AS CONTRACT_BEGIN_DATE,                           -- 合同开始时间
  a.END_TIME AS CONTRACT_END_DATE,                               -- 合同结束时间
  a.HZFZR AS LINKMAN,                                            -- 联系人
  '000000' AS PROCESS_ID   ,                                     -- 流程实例ID
  NULL AS  REVIEW_REMARK,
   IFNULL(v.new_id,'999999999') AS REVIEW_ID,
   v_n.NAME AS REVIEW_NAME,
   IFNULL(a.MANAGER_APPROVE_TIME,SYSDATE()) AS REVIEW_TIME,
  'sfy' AS SYSTEM_SOURCE                                         -- 系统来源
FROM
  sogaldb.DMS_FILED_COOPERATOR a
LEFT JOIN max_test.map_emp guardian ON a.WINDOW=guardian.old_id 
LEFT JOIN dspdb.DEALER_EMPLOYEE b ON b.ID = guardian.new_id
LEFT JOIN max_test.map_emp creater ON a.CREATE_BY=creater.old_id 
LEFT JOIN max_test.map_emp laster ON a.LAST_UPDATE_BY=laster.old_id 
-- LEFT JOIN sogaldb.SG_ORGANIZATION c ON a.STORE_ID = c.ORG_ID
LEFT JOIN max_test.map_emp v ON v.old_id=a.MANAGER_APPROVE_BY
LEFT JOIN dspdb.DEALER_EMPLOYEE v_n ON v_n.ID = v.new_id
LEFT JOIN sfy_zy_def.eos_dict_entry  bank ON a.ACCOUNT_BANK= bank.DICTID AND  bank.`DICTTYPEID`='bank'  -- 配置表
LEFT JOIN -- 计算协同未结束的积分（冻结积分）
(
  SELECT
    d.COOPERATOR_ID,
    SUM(e.CHANG_CASH_AMOUNT) AS BAK
  FROM
    sfy_xt.dms_wf_score_change_cash d
  RIGHT JOIN sfy_xt.dms_wf_score_change_cash_ext e ON d.PK_ID = e.PARENT_ID
  LEFT JOIN sfy_xt.sfy_flow_info f ON d.PROCESS_INST_ID = f.process_inst_id
  WHERE  f.current_state = "2" GROUP BY d.COOPERATOR_ID
) g ON a.FILED_ID = g.COOPERATOR_ID
LEFT JOIN -- 增项积分总和（累计获得积分（只增不减））
(
  SELECT
    h.FILED_ID,
    SUM(ABS(h.INTEGRAL_COUNT)) AS BAK
  FROM
    sogaldb.DMS_CUSTOM_INTEGRAL_MANAGER_RECORD h
  WHERE
    h.OPERATOR_TYPE IN ('1', '3')
  GROUP BY
    h.FILED_ID
) i ON a.FILED_ID = i.FILED_ID
LEFT JOIN -- 减项积分总和（累计消费积分（只增不减））
(
  SELECT
    j.FILED_ID,
    SUM(ABS(j.INTEGRAL_COUNT)) AS BAK
  FROM
    sogaldb.DMS_CUSTOM_INTEGRAL_MANAGER_RECORD j
  WHERE
    j.OPERATOR_TYPE IN ('2', '4')
  GROUP BY
j.FILED_ID
) k ON a.FILED_ID = k.FILED_ID
LEFT JOIN max_test.map_org m ON a.STORE_ID = m.old_id
AND m.source IN ('sg_xt','')
LEFT JOIN max_test.channal_level_ys n ON a.LEVEL = n.old_id;      -- 合作方会员等级映射表
-- LEFT JOIN max_test.map_customer_id T1 ON a.FILED_ID=T1.id;       -- 用于匹配老客户id，在存储过程开头建立
ALTER TABLE max_test.CHANNEL_COOPERATOR MODIFY bank VARCHAR(50);
-- 司米
INSERT INTO max_test.CHANNEL_COOPERATOR
SELECT
  a.FILED_ID AS ID,                                              -- 合作方id
--  T1.CUSTOMER_ID AS CUSTOMER_ID,                                 -- 老客户ID
  NULL AS CUSTOMER_ID,
  a.NOTE AS COMMENTS,                                            -- 备注
  CASE WHEN a.FILE_TYPE='1' THEN 'DESIGNER'
       WHEN a.FILE_TYPE='2' THEN 'COMPANY'
       WHEN a.FILE_TYPE='3' THEN 'CUSTOMER'
       WHEN a.FILE_TYPE='4' THEN 'FOREMAN'
       WHEN a.FILE_TYPE='5' THEN 'CUSTOMER'
       WHEN a.FILE_TYPE='6' THEN 'BRAND'
       WHEN a.FILE_TYPE='7' THEN 'DIFFERENT'
       WHEN a.FILE_TYPE='8' THEN 'TEAM'
       WHEN a.FILE_TYPE='9' THEN 'RESIDENTIAL'
       WHEN a.FILE_TYPE='10' THEN 'CUSTOMER'
  ELSE a.FILE_TYPE
  END AS TYPE,                                                   -- 合作方类型
  a.COOPERATOR_NAME AS NAME,                                     -- 合作方名称
  RTRIM(REPLACE(a.TEL,'-','')) AS MOBILE,                        -- 手机号
  a.ACCOUNT_BANK AS BANK,                                        -- 开户银行
   bank.DICTNAME AS BANK1,
  a.BRANCH_BANK AS BRANCH,                                       -- 支行名称
  a.ACCOUNT AS ACCOUNT,                                          -- 银行账户
  a.ACCOUNT_NAME AS ACCOUNT_NAME,                                -- 账户名称
  a.ADDRESS AS ADDR,                                             -- 地址（街道、园区、写字楼）
  n.new_id AS LEVEL_ID,                                          -- 级别
  a.WINDOW AS GUARDIAN_ID,                                       -- 维护人id
  IFNULL(guardian.new_id,'999999999') GUARDIAN_ID1,              -- 新的维护人id
  b.NAME AS GUARDIAN_NAME,                                       -- 维护人姓名
  CASE WHEN a.STATUS='1' AND a.FILE_TYPE NOT IN ('3','5','10') THEN 'APPROVING'
       WHEN a.STATUS='1' AND a.FILE_TYPE     IN ('3','5','10') THEN 'PASSED'
       WHEN a.STATUS='2' AND a.FILE_TYPE NOT IN ('3','5','10') THEN 'APPROVING'
       WHEN a.STATUS='2' AND a.FILE_TYPE     IN ('3','5','10') THEN 'PASSED'
       WHEN a.STATUS='3' AND a.FILE_TYPE NOT IN ('3','5','10') THEN 'SENDBACK'
       WHEN a.STATUS='3' AND a.FILE_TYPE     IN ('3','5','10') THEN 'PASSED'
       WHEN a.STATUS='4' THEN 'PASSED'
       END AS STATUS,                                            -- 审批状态dict
  a.CREATE_BY AS CREATOR_ID,                                     -- 创建人ID
  IFNULL(creater.new_id,'999999999') AS CREATOR_ID1,
  IFNULL(a.CREATE_TIME,SYSDATE()) AS TIME_CREATED,               -- 创建时间
  a.LAST_UPDATE_BY AS LAST_UPDATED_BY,                           -- 最后更新操作人ID
  IFNULL(laster.new_id,'999999999') AS LAST_UPDATED_BY1,
  a.LAST_UPDATE_TIME AS LAST_UPDATE_TIME,                        -- 最后更新时间
  IFNULL(m.new_id,'999999999') AS CREATOR_ORG_ID,                -- 创建人所属门店ID
  m.new_name AS CREATOR_ORG_NAME,                                -- 创建人所属门店名称
  '010',                                                         -- 经销商ID
  IFNULL(a.CREDITS,'') AS INTEGRAL,                              -- 积分余额
  IFNULL(g.BAK,'') AS INTEGRAL_FROZEN,                           -- 冻结积分
  IFNULL(i.BAK,'') AS INTEGRAL_TOTAL,                            -- 累计获得积分（只增不减）
  IFNULL(k.BAK,'') AS INTEGRAL_CONSUMED,                         -- 累计消费积分（只增不减）
  a.DECORATE_COMPANY AS BELONG_COMPANY,                          -- 所属装饰公司
  a.LINK_TEL AS COMPANY_TEL,                                     -- 公司电话
  a.START_TIME AS CONTRACT_BEGIN_DATE,                           -- 合同开始时间
  a.END_TIME AS CONTRACT_END_DATE,                               -- 合同结束时间
  a.HZFZR AS LINKMAN,                                            -- 联系人
  '000000' AS PROCESS_ID  ,                                      -- 流程实例ID
   NULL AS  REVIEW_REMARK,
    IFNULL(v.new_id,'999999999') AS REVIEW_ID,
    v_n.NAME AS REVIEW_NAME,
   IFNULL(a.MANAGER_APPROVE_TIME,SYSDATE()) AS REVIEW_TIME,
  'sm' AS SYSTEM_SOURCE
FROM
  sm_zy.dms_filed_cooperator a
LEFT JOIN max_test.map_emp guardian ON a.WINDOW=guardian.old_id
LEFT JOIN dspdb.DEALER_EMPLOYEE b ON b.ID = guardian.new_id
LEFT JOIN max_test.map_emp creater ON a.CREATE_BY=creater.old_id 
LEFT JOIN max_test.map_emp laster ON a.LAST_UPDATE_BY=laster.old_id 
-- LEFT JOIN sm_zy.sg_organization c ON a.STORE_ID = c.ORG_ID
LEFT JOIN max_test.map_emp v ON v.old_id=a.MANAGER_APPROVE_BY
LEFT JOIN dspdb.DEALER_EMPLOYEE v_n ON v_n.ID = v.new_id
LEFT JOIN sfy_zy_def.eos_dict_entry bank ON a.ACCOUNT_BANK= bank.DICTID AND bank.`DICTTYPEID`='bank'
LEFT JOIN
( -- 计算协同未结束的积分（冻结积分）
  SELECT
    d.COOPERATOR_ID,
    SUM(e.CHANG_CASH_AMOUNT) AS BAK
  FROM
    sm_xt.dms_wf_score_change_cash d
  RIGHT JOIN sm_xt.dms_wf_score_change_cash_ext e ON d.PK_ID = e.PARENT_ID
  LEFT JOIN sm_xt.sfy_flow_info f ON d.PROCESS_INST_ID = f.process_inst_id
  WHERE
    f.current_state = "2"
  GROUP BY
    d.COOPERATOR_ID
) g ON a.FILED_ID = g.COOPERATOR_ID
LEFT JOIN
( -- 增项积分总和（累计获得积分（只增不减））
  SELECT
    h.FILED_ID,
    SUM(ABS(h.INTEGRAL_COUNT)) AS BAK
  FROM
    sm_zy.dms_custom_integral_manager_record h
  WHERE
    h.OPERATOR_TYPE IN ('1', '3')
  GROUP BY
    h.FILED_ID
) i ON a.FILED_ID = i.FILED_ID
LEFT JOIN
( -- 减项积分总和（累计消费积分（只增不减））
  SELECT
    j.FILED_ID,
    SUM(ABS(j.INTEGRAL_COUNT)) AS BAK
  FROM
    sm_zy.dms_custom_integral_manager_record j
  WHERE
    j.OPERATOR_TYPE IN ('2', '4')
  GROUP BY
    j.FILED_ID
) k ON a.FILED_ID = k.FILED_ID
LEFT JOIN max_test.map_org m ON a.STORE_ID = m.old_id
AND m.source IN ('sm_xt','')
LEFT JOIN max_test.channal_level_ys n ON a.LEVEL = n.old_id;
-- LEFT JOIN max_test.map_customer_id T1 ON a.FILED_ID=T1.id;
-- 清洗数据
#DROP TABLE IF EXISTS max_test.CHANNEL_COOPERATOR1;
#CREATE TABLE max_test.CHANNEL_COOPERATOR1 AS 
TRUNCATE TABLE max_test.CHANNEL_COOPERATOR1;
INSERT INTO max_test.CHANNEL_COOPERATOR1
SELECT * FROM max_test.CHANNEL_COOPERATOR;
-- ALTER TABLE max_test.CHANNEL_COOPERATOR1 ADD INDEX IDX_CHANNEL_COOPERATOR1(ID);
UPDATE max_test.CHANNEL_COOPERATOR1 SET MOBILE=NAME WHERE ID= '14904681-5fc8-4118-8725-a67201254b35';  
UPDATE max_test.CHANNEL_COOPERATOR1 SET MOBILE=LEFT(REPLACE(REPLACE(MOBILE,' ',''),'-',''),11) WHERE  LENGTH(MOBILE)>12;
-- 修改手机号变更的数据
UPDATE max_test.CHANNEL_COOPERATOR1 SET mobile='18603620578' WHERE id='ff8080815db865c8015dbb716c3e0137';
UPDATE max_test.CHANNEL_COOPERATOR1 SET mobile='010-56230046' WHERE id='ff8080815e08bf4e015e0909fc9800fd';
UPDATE max_test.CHANNEL_COOPERATOR1 SET mobile='13911227423' WHERE id='91bcb7e3-376e-4641-ad4a-a51100f09f9d';
-- 把银行编码转换成中文
 UPDATE  max_test.CHANNEL_COOPERATOR1 t 
 SET BANK1=BANK WHERE BANK1 IS NULL AND IFNULL(BANK,'')<>'';
 
-- 把 账号是银行的数据替换到bank1
UPDATE max_test.CHANNEL_COOPERATOR1 t SET BANK1=ACCOUNT   WHERE ACCOUNT LIKE'%行' AND ACCOUNT<>''
AND ACCOUNT NOT LIKE '%00%'  AND bank!='3';
   
-- 把bank 中是账号的数据替换到account
UPDATE  max_test.CHANNEL_COOPERATOR1  t SET ACCOUNT= BANK    WHERE   ACCOUNT<>'' AND  ACCOUNT LIKE'%行'  AND  ACCOUNT NOT LIKE '%0%'
   AND BANK!='3';
UPDATE max_test.CHANNEL_COOPERATOR1   SET bank1='建设银行' WHERE  bank1='建行';
UPDATE max_test.CHANNEL_COOPERATOR1   SET bank1='工商银行' WHERE  bank1 LIKE'%工商%';
UPDATE max_test.CHANNEL_COOPERATOR1   SET bank1='招商银行' WHERE  bank1='招行';
UPDATE max_test.CHANNEL_COOPERATOR1   SET bank1='中国银行' WHERE  branch LIKE '%中国银行%';
UPDATE max_test.CHANNEL_COOPERATOR1   SET bank1='浦发银行' WHERE  bank1='上海浦东发展银行';
UPDATE max_test.CHANNEL_COOPERATOR1 SET  bank1= CASE WHEN  bank1 LIKE '%邮政%' THEN '邮政储蓄'
        WHEN  bank1 LIKE '%中国银行%' THEN '中国银行'
        WHEN INSTR( REPLACE (bank1, '中国', ''), '行' )>0
         THEN   LEFT ( REPLACE (bank1, '中国', ''), INSTR( REPLACE (bank1, '中国', ''), '行' ) )
    ELSE bank1 END;
/*
-- 查询重复电话号的sql
-- create table max_test.CHANNEL_COOPERATOR2 
select * from  max_test.CHANNEL_COOPERATOR1 where   MOBILE in(
select t.MOBILE  
from max_test.CHANNEL_COOPERATOR1 t group by t.MOBILE having count(1)>2)
and mobile not in  (select 手机号 from max_test.CHANNEL_COOPERATOR_GOOD) order by MOBILE ;*/
-- good表中数据
#DROP TABLE IF EXISTS max_test.CHANNEL_COOPERATOR2;
#CREATE TABLE max_test.CHANNEL_COOPERATOR2
TRUNCATE TABLE max_test.CHANNEL_COOPERATOR2;
INSERT INTO max_test.CHANNEL_COOPERATOR2
SELECT
	t1.ID,
	t1.CUSTOMER_ID,
	t1.COMMENTS,
	t1.TYPE,
	t1. NAME,
        CAST(CASE WHEN LEFT(TRIM(REPLACE(t1.MOBILE, '\t', '')), 11) REGEXP "^[1][3456789][0-9]{9}$" THEN LEFT(TRIM(REPLACE(t1.MOBILE, '\t', '')), 11) 
             ELSE RIGHT(TRIM(REPLACE(t1.MOBILE, '\t', '')), 11)
        END AS CHAR(20)) AS MOBILE,
	t1.BANK1,
        dic.VALUE AS BANK,
	t1.BRANCH,
	t1.ACCOUNT,
	t1.ACCOUNT_NAME,
	t1.ADDR,
	t1.LEVEL_ID,
	t1.GUARDIAN_ID1 AS GUARDIAN_ID,
	t1.GUARDIAN_NAME,
	t1. STATUS,
	t1.CREATOR_ID1 AS CREATOR_ID,
	t1.TIME_CREATED,
	t1.LAST_UPDATED_BY1 AS LAST_UPDATED_BY,
	t1.LAST_UPDATE_TIME,
	t1.CREATOR_ORG_ID,
	t1.CREATOR_ORG_NAME,
	'010' AS DEALER_CODE,
	CONVERT(t1.INTEGRAL,DECIMAL)INTEGRAL ,
	CONVERT(t1.INTEGRAL_FROZEN,DECIMAL)INTEGRAL_FROZEN,
	CONVERT(t1.INTEGRAL_TOTAL,DECIMAL)INTEGRAL_TOTAL,
	CONVERT(t1.INTEGRAL_CONSUMED,DECIMAL)INTEGRAL_CONSUMED,
	t1.BELONG_COMPANY,
	t1.COMPANY_TEL,
	t1.CONTRACT_BEGIN_DATE,
	t1.CONTRACT_END_DATE,
	t1.LINKMAN,
	t1.PROCESS_ID,
	t1.REVIEW_REMARK,
	t1.REVIEW_ID,
	t1.REVIEW_NAME,
	t1.REVIEW_TIME,
	t1.SYSTEM_SOURCE
FROM max_test.CHANNEL_COOPERATOR1 t1
LEFT JOIN dspdb.SYS_DICT dic ON t1.bank1=dic.LABEL AND dic.TYPE='BANK'
JOIN max_test.CHANNEL_COOPERATOR_GOOD t2 ON t1.id = t2.`合作方id`
AND t2.`保留/删除` = '保留';
-- good1表的数据
INSERT INTO max_test.CHANNEL_COOPERATOR2
SELECT
	t1.ID,
	t1.CUSTOMER_ID,
	t1.COMMENTS,
	t1.TYPE,
	t1. NAME,
        CASE WHEN LEFT(TRIM(REPLACE(t1.MOBILE, '\t', '')), 11) REGEXP "^[1][3456789][0-9]{9}$" THEN LEFT(TRIM(REPLACE(t1.MOBILE, '\t', '')), 11) 
             ELSE RIGHT(TRIM(REPLACE(t1.MOBILE, '\t', '')), 11)
        END AS MOBILE,
	t1.BANK1,
        dic.VALUE AS BANK,
	t1.BRANCH,
	t1.ACCOUNT,
	t1.ACCOUNT_NAME,
	t1.ADDR,
	t1.LEVEL_ID,
	t1.GUARDIAN_ID1 AS GUARDIAN_ID,
	t1.GUARDIAN_NAME,
	t1. STATUS,
	t1.CREATOR_ID1 AS CREATOR_ID,
	t1.TIME_CREATED,
	t1.LAST_UPDATED_BY1 AS LAST_UPDATED_BY,
	t1.LAST_UPDATE_TIME,
	t1.CREATOR_ORG_ID,
	t1.CREATOR_ORG_NAME,
	'010' AS DEALER_CODE,
	CONVERT(t1.INTEGRAL,DECIMAL) ,
	CONVERT(t1.INTEGRAL_FROZEN,DECIMAL),
	CONVERT(t1.INTEGRAL_TOTAL,DECIMAL),
	CONVERT(t1.INTEGRAL_CONSUMED,DECIMAL),
	t1.BELONG_COMPANY,
	t1.COMPANY_TEL,
	t1.CONTRACT_BEGIN_DATE,
	t1.CONTRACT_END_DATE,
	t1.LINKMAN,
	t1.PROCESS_ID,
	t1. REVIEW_REMARK,
	t1. REVIEW_ID,
	t1. REVIEW_NAME,
	t1. REVIEW_TIME,
	t1.SYSTEM_SOURCE
FROM max_test.CHANNEL_COOPERATOR1 t1
LEFT JOIN dspdb.SYS_DICT dic ON t1.bank1=dic.LABEL AND dic.TYPE='BANK'
JOIN max_test.CHANNEL_COOPERATOR_GOOD1 t2 ON t1.id = t2.`合作方id` AND t2.`保留/删除`='保留';
-- 排除good和good1表的数据
INSERT INTO max_test.CHANNEL_COOPERATOR2
SELECT
	t1.ID,
	t1.CUSTOMER_ID,
	t1.COMMENTS,
	t1.TYPE,
	t1. NAME,
        CASE WHEN LEFT(TRIM(REPLACE(t1.MOBILE, '\t', '')), 11) REGEXP "^[1][3456789][0-9]{9}$" THEN LEFT(TRIM(REPLACE(t1.MOBILE, '\t', '')), 11) 
             ELSE RIGHT(TRIM(REPLACE(t1.MOBILE, '\t', '')), 11)
        END AS MOBILE,
	t1.BANK1,
        dic.VALUE AS BANK,
	t1.BRANCH,
	t1.ACCOUNT,
	t1.ACCOUNT_NAME,
	t1.ADDR,
	t1.LEVEL_ID,
	t1.GUARDIAN_ID1 AS GUARDIAN_ID,
	t1.GUARDIAN_NAME,
	t1. STATUS,
	t1.CREATOR_ID1 AS CREATOR_ID,
	t1.TIME_CREATED,
	t1.LAST_UPDATED_BY1 AS LAST_UPDATED_BY,
	t1.LAST_UPDATE_TIME,
	t1.CREATOR_ORG_ID,
	t1.CREATOR_ORG_NAME,
	'010' AS DEALER_CODE,
	CONVERT(t1.INTEGRAL,DECIMAL)INTEGRAL ,
	CONVERT(t1.INTEGRAL_FROZEN,DECIMAL)INTEGRAL_FROZEN,
	CONVERT(t1.INTEGRAL_TOTAL,DECIMAL)INTEGRAL_TOTAL,
	CONVERT(t1.INTEGRAL_CONSUMED,DECIMAL)INTEGRAL_CONSUMED,
	t1.BELONG_COMPANY,
	t1.COMPANY_TEL,
	t1.CONTRACT_BEGIN_DATE,
	t1.CONTRACT_END_DATE,
	t1.LINKMAN,
	t1.PROCESS_ID,
	t1.REVIEW_REMARK,
	t1.REVIEW_ID,
	t1.REVIEW_NAME,
	t1.REVIEW_TIME,
	t1.SYSTEM_SOURCE
FROM max_test.CHANNEL_COOPERATOR1 t1
LEFT JOIN dspdb.SYS_DICT dic ON t1.bank1=dic.LABEL AND dic.TYPE='BANK'
WHERE t1.ID NOT IN
(SELECT DISTINCT 合作方id FROM max_test.CHANNEL_COOPERATOR_GOOD
UNION
SELECT DISTINCT 合作方id FROM max_test.CHANNEL_COOPERATOR_GOOD1);
-- 删除映射表
#DROP TABLE IF EXISTS max_test.map_channel_cooperator;
-- 新建映射表
#CREATE TABLE max_test.map_channel_cooperator
TRUNCATE TABLE max_test.map_channel_cooperator;
INSERT INTO max_test.map_channel_cooperator
SELECT 
   CAST(a.mobile AS CHAR(20)) AS tel
  ,a.ID AS old_id
  ,b.`合作方id` AS new_id
  ,'删除' AS STATUS
FROM 
(SELECT ID,mobile FROM max_test.CHANNEL_COOPERATOR2
                WHERE MOBILE IN (SELECT mobile FROM max_test.CHANNEL_COOPERATOR2 GROUP BY mobile HAVING COUNT(1)>1)   -- 重复的数据
                AND MOBILE IN (SELECT `手机号` FROM max_test.CHANNEL_COOPERATOR_GOOD)        -- 手机号在good中
                AND ID NOT IN (SELECT `合作方id` FROM max_test.CHANNEL_COOPERATOR_GOOD WHERE `保留/删除`='保留')
                ORDER BY mobile) a
LEFT JOIN max_test.CHANNEL_COOPERATOR_GOOD b ON a.mobile=b.`手机号` AND b.`保留/删除`='保留';
-- 插入数据
INSERT INTO max_test.map_channel_cooperator
SELECT 
   a.mobile AS tel
  ,a.ID AS old_id
  ,b.`合作方id` AS new_id
  ,'删除' AS STATUS
FROM 
(
SELECT ID,mobile FROM max_test.CHANNEL_COOPERATOR2
                WHERE MOBILE IN (SELECT mobile FROM max_test.CHANNEL_COOPERATOR2 GROUP BY mobile HAVING COUNT(1)>1)   -- 重复的数据
                AND MOBILE IN (SELECT `手机号` FROM max_test.CHANNEL_COOPERATOR_GOOD1)        -- 手机号在good中
                AND ID NOT IN (SELECT `合作方id` FROM max_test.CHANNEL_COOPERATOR_GOOD1 WHERE `保留/删除`='保留')
ORDER BY mobile
) a
LEFT JOIN max_test.CHANNEL_COOPERATOR_GOOD1 b ON a.mobile=b.`手机号` AND b.`保留/删除`='保留';
-- 删除 增量且之前确认（在good表存在）过的手机号
DELETE FROM max_test.CHANNEL_COOPERATOR2 WHERE ID IN
(SELECT * FROM (SELECT ID FROM max_test.CHANNEL_COOPERATOR2
                WHERE MOBILE IN (SELECT mobile FROM max_test.CHANNEL_COOPERATOR2 GROUP BY mobile HAVING COUNT(1)>1)   -- 重复的数据
                AND MOBILE IN (SELECT `手机号` FROM max_test.CHANNEL_COOPERATOR_GOOD)        -- 手机号在good中
                AND ID NOT IN (SELECT `合作方id` FROM max_test.CHANNEL_COOPERATOR_GOOD WHERE `保留/删除`='保留')      -- 合作方id不在good中
) a);
-- 删除 增量且之前确认（在good1表存在）过的手机号
DELETE FROM max_test.CHANNEL_COOPERATOR2 WHERE ID IN
(SELECT * FROM (SELECT ID FROM max_test.CHANNEL_COOPERATOR2
                WHERE MOBILE IN (SELECT mobile FROM max_test.CHANNEL_COOPERATOR2 GROUP BY mobile HAVING COUNT(1)>1)   -- 重复的数据
                AND MOBILE IN (SELECT `手机号` FROM max_test.CHANNEL_COOPERATOR_GOOD1)        -- 手机号在good中
                AND ID NOT IN (SELECT `合作方id` FROM max_test.CHANNEL_COOPERATOR_GOOD1 WHERE `保留/删除`='保留')      -- 合作方id不在good中
) a);
-- 脚本实现电话号排重部分
-- 司索同时存在的电话号取索菲亚
#DROP TABLE IF EXISTS max_test.CHANNEL_COOPERATOR3;
#CREATE TABLE max_test.CHANNEL_COOPERATOR3
TRUNCATE TABLE max_test.CHANNEL_COOPERATOR3;
INSERT INTO max_test.CHANNEL_COOPERATOR3
SELECT
   *
FROM max_test.CHANNEL_COOPERATOR2 t1
WHERE t1.mobile IN (SELECT mobile FROM max_test.CHANNEL_COOPERATOR2 WHERE system_source='sfy' GROUP BY mobile HAVING COUNT(1)=1)
AND t1.mobile IN (SELECT mobile FROM max_test.CHANNEL_COOPERATOR2 WHERE system_source='sm' )
AND t1.system_source='sfy'
ORDER BY t1.mobile;
-- 排除 司索同时存在的电话号 后的数据
INSERT INTO max_test.CHANNEL_COOPERATOR3
SELECT
   *
FROM max_test.CHANNEL_COOPERATOR2
WHERE ID NOT IN
(SELECT ID FROM max_test.CHANNEL_COOPERATOR2
WHERE mobile IN (SELECT mobile FROM max_test.CHANNEL_COOPERATOR2 WHERE system_source='sfy' GROUP BY mobile HAVING COUNT(1)=1)
AND mobile IN (SELECT mobile FROM max_test.CHANNEL_COOPERATOR2 WHERE system_source='sm'));
-- 插入目标表数据				
-- TRUNCATE TABLE dspdb.CHANNEL_COOPERATOR;
INSERT INTO dspdb.CHANNEL_COOPERATOR
   (ID,
   CUSTOMER_ID,
   COMMENTS,
   TYPE,
   NAME,
   MOBILE,
   BANK,
   BRANCH,
   ACCOUNT,
   ACCOUNT_NAME,
   ADDR,
   LEVEL_ID,
   GUARDIAN_ID,
   GUARDIAN_NAME,
   STATUS,
   CREATOR_ID,
   TIME_CREATED,
   LAST_UPDATED_BY,
   LAST_UPDATE_TIME,
   CREATOR_ORG_ID,
   CREATOR_ORG_NAME,
   DEALER_CODE,
   INTEGRAL,
   INTEGRAL_FROZEN,
   INTEGRAL_TOTAL,
   INTEGRAL_CONSUMED,
   BELONG_COMPANY,
   COMPANY_TEL,
   CONTRACT_BEGIN_DATE,
   CONTRACT_END_DATE,
   LINKMAN,
   PROCESS_ID,
   REVIEW_REMARK,
   REVIEW_ID,
   REVIEW_NAME,
   REVIEW_TIME)
SELECT
     a.ID,
     a.CUSTOMER_ID,
     a.COMMENTS,
     a.TYPE,
     a.NAME,
     a.MOBILE,   
     a.BANK,
     a.BRANCH,
     a.ACCOUNT,
     a.ACCOUNT_NAME,
     a.ADDR,
     a.LEVEL_ID,
     a.GUARDIAN_ID,
     a.GUARDIAN_NAME,
     a.STATUS,
     a.CREATOR_ID,
     a.TIME_CREATED,
     a.LAST_UPDATED_BY,
     a.LAST_UPDATE_TIME,
     a.CREATOR_ORG_ID,
     a.CREATOR_ORG_NAME,
     a.DEALER_CODE,
     b.INTEGRAL,
     b.INTEGRAL_FROZEN,
     b.INTEGRAL_TOTAL,
     b.INTEGRAL_CONSUMED,
     a.BELONG_COMPANY,
     a.COMPANY_TEL,
     a.CONTRACT_BEGIN_DATE,
     a.CONTRACT_END_DATE,
     a.LINKMAN,
     a.PROCESS_ID,
     a.REVIEW_REMARK,
     a.REVIEW_ID,
     a.REVIEW_NAME,
     a.REVIEW_TIME
FROM max_test.CHANNEL_COOPERATOR3 a
LEFT JOIN 
(SELECT 
     a.mobile
    ,SUM(a.INTEGRAL) AS INTEGRAL
    ,SUM(a.INTEGRAL_FROZEN) AS INTEGRAL_FROZEN
    ,SUM(a.INTEGRAL_TOTAL) AS INTEGRAL_TOTAL
    ,SUM(a.INTEGRAL_CONSUMED) AS INTEGRAL_CONSUMED
FROM max_test.CHANNEL_COOPERATOR1 a
GROUP BY a.mobile) b ON a.MOBILE=b.mobile;
-- 新建临时表，修正错非老客户误积分
#DROP TABLE IF EXISTS max_test.channel_cooperator_hezuo;
#CREATE TABLE max_test.channel_cooperator_hezuo
TRUNCATE TABLE max_test.channel_cooperator_hezuo;
INSERT INTO max_test.channel_cooperator_hezuo
SELECT
   *
FROM dspdb.CHANNEL_COOPERATOR a WHERE a.INTEGRAL+a.INTEGRAL_FROZEN+a.INTEGRAL_CONSUMED!=a.INTEGRAL_TOTAL
AND a.TYPE!='CUSTOMER';
DELETE FROM dspdb.CHANNEL_COOPERATOR WHERE INTEGRAL+INTEGRAL_FROZEN+INTEGRAL_CONSUMED!=INTEGRAL_TOTAL
AND TYPE!='CUSTOMER';
INSERT INTO dspdb.CHANNEL_COOPERATOR
SELECT
   a.ID
  ,a.CUSTOMER_ID
  ,a.COMMENTS
  ,a.TYPE
  ,a.NAME
  ,a.MOBILE
  ,a.BANK
  ,a.BRANCH
  ,a.ACCOUNT
  ,a.ACCOUNT_NAME
  ,a.ADDR
  ,a.LEVEL_ID
  ,a.GUARDIAN_ID
  ,a.GUARDIAN_NAME
  ,a.STATUS
  ,a.CREATOR_ID
  ,a.TIME_CREATED
  ,a.LAST_UPDATED_BY
  ,a.LAST_UPDATE_TIME
  ,a.CREATOR_ORG_ID
  ,a.CREATOR_ORG_NAME
  ,a.DEALER_CODE
  ,a.INTEGRAL_TOTAL-a.INTEGRAL_CONSUMED-a.INTEGRAL_FROZEN
  ,a.INTEGRAL_FROZEN
  ,a.INTEGRAL_TOTAL
  ,a.INTEGRAL_CONSUMED
  ,a.BELONG_COMPANY
  ,a.COMPANY_TEL
  ,a.CONTRACT_BEGIN_DATE
  ,a.CONTRACT_END_DATE
  ,a.LINKMAN
  ,a.PROCESS_ID
  ,a.REVIEW_REMARK
  ,a.REVIEW_ID
  ,a.REVIEW_NAME
  ,a.REVIEW_TIME
FROM max_test.channel_cooperator_hezuo a;
-- drop table if exists max_test.channel_cooperator_hezuo;
-- 修正老客户错误数据
#DROP TABLE IF EXISTS max_test.channel_cooperator_kehu;
#CREATE TABLE max_test.channel_cooperator_kehu
TRUNCATE TABLE max_test.channel_cooperator_kehu;
INSERT INTO max_test.channel_cooperator_kehu
SELECT
   *
FROM dspdb.CHANNEL_COOPERATOR a WHERE a.INTEGRAL+a.INTEGRAL_FROZEN+a.INTEGRAL_CONSUMED!=a.INTEGRAL_TOTAL
AND a.TYPE='CUSTOMER';
DELETE FROM dspdb.CHANNEL_COOPERATOR WHERE INTEGRAL+INTEGRAL_FROZEN+INTEGRAL_CONSUMED!=INTEGRAL_TOTAL
AND TYPE='CUSTOMER';
INSERT INTO dspdb.CHANNEL_COOPERATOR
SELECT
   a.ID
  ,a.CUSTOMER_ID
  ,a.COMMENTS
  ,a.TYPE
  ,a.NAME
  ,a.MOBILE
  ,a.BANK
  ,a.BRANCH
  ,a.ACCOUNT
  ,a.ACCOUNT_NAME
  ,a.ADDR
  ,a.LEVEL_ID
  ,a.GUARDIAN_ID
  ,a.GUARDIAN_NAME
  ,a.STATUS
  ,a.CREATOR_ID
  ,a.TIME_CREATED
  ,a.LAST_UPDATED_BY
  ,a.LAST_UPDATE_TIME
  ,a.CREATOR_ORG_ID
  ,a.CREATOR_ORG_NAME
  ,a.DEALER_CODE
  ,b.INTEGRAL
  ,b.INTEGRAL_FROZEN
  ,b.INTEGRAL_TOTAL
  ,b.INTEGRAL_CONSUMED
  ,a.BELONG_COMPANY
  ,a.COMPANY_TEL
  ,a.CONTRACT_BEGIN_DATE
  ,a.CONTRACT_END_DATE
  ,a.LINKMAN
  ,a.PROCESS_ID
  ,a.REVIEW_REMARK
  ,a.REVIEW_ID
  ,a.REVIEW_NAME
  ,a.REVIEW_TIME
FROM max_test.channel_cooperator_kehu a
LEFT JOIN max_test.Sheet3 b ON a.ID=b.ID;
-- DROP TABLE IF EXISTS max_test.channel_cooperator_kehu;
UPDATE dspdb.`CHANNEL_COOPERATOR` SET account=REPLACE(account,' ','');
-- 合作方映射表
-- 脚本筛选的数据
#DROP TABLE IF EXISTS max_test.CHANNEL_COOPERATOR_GOOD2;
#CREATE TABLE max_test.CHANNEL_COOPERATOR_GOOD2
TRUNCATE TABLE max_test.CHANNEL_COOPERATOR_GOOD2;
INSERT INTO max_test.CHANNEL_COOPERATOR_GOOD2
SELECT
    t1.ID AS `合作方id`
   ,t1.MOBILE AS `手机号`
   ,CASE WHEN t1.system_source='sfy' THEN '保留'
         WHEN t1.system_source='sm'  THEN '删除'
    END AS `保留/删除`
FROM max_test.CHANNEL_COOPERATOR2 t1
WHERE t1.mobile IN (SELECT mobile FROM max_test.CHANNEL_COOPERATOR2 WHERE system_source='sfy' GROUP BY mobile HAVING COUNT(1)=1)
AND t1.mobile IN (SELECT mobile FROM max_test.CHANNEL_COOPERATOR2 WHERE system_source='sm');
-- 插入映射表数据
INSERT INTO max_test.map_channel_cooperator
SELECT DISTINCT 
  t1.`手机号` AS tel,
  t1.`合作方id` AS old_id,
  CASE WHEN t1.`保留/删除` = '删除' THEN t2.`合作方id` 
       ELSE t1.`合作方id` 
       END AS new_id,
  t1.`保留/删除` AS `status` 
FROM max_test.CHANNEL_COOPERATOR_GOOD t1 
LEFT JOIN max_test.CHANNEL_COOPERATOR_GOOD t2 ON t1.`手机号` = t2.`手机号` AND t2.`保留/删除` = '保留'
WHERE t1.`手机号` NOT IN (SELECT `手机号` FROM max_test.CHANNEL_COOPERATOR_GOOD2);
-- 插入数据
INSERT INTO max_test.map_channel_cooperator
SELECT DISTINCT 
  t1.`手机号` AS tel,
  t1.`合作方id` AS old_id,
  CASE WHEN t1.`保留/删除` = '删除' THEN t2.`合作方id` 
       ELSE t1.`合作方id` 
       END AS new_id,
  t1.`保留/删除` AS `status` 
FROM max_test.CHANNEL_COOPERATOR_GOOD1 t1 
LEFT JOIN max_test.CHANNEL_COOPERATOR_GOOD1 t2 ON t1.`手机号` = t2.`手机号` AND t2.`保留/删除` = '保留'
WHERE t1.`手机号` NOT IN (SELECT `手机号` FROM max_test.CHANNEL_COOPERATOR_GOOD2);
-- 插入数据
INSERT INTO max_test.map_channel_cooperator
SELECT DISTINCT 
  t1.`手机号` AS tel,
  t1.`合作方id` AS old_id,
  CASE WHEN t1.`保留/删除` = '删除' THEN t2.`合作方id` 
       ELSE t1.`合作方id` 
       END AS new_id,
  t1.`保留/删除` AS `status` 
FROM max_test.CHANNEL_COOPERATOR_GOOD2 t1 
LEFT JOIN max_test.CHANNEL_COOPERATOR_GOOD2 t2 ON t1.`手机号` = t2.`手机号` AND t2.`保留/删除` = '保留';
-- 插入数据
INSERT INTO max_test.map_channel_cooperator
SELECT 
  a.MOBILE,
  a.ID,
  a.ID,
  '保留' 
FROM
  dspdb.CHANNEL_COOPERATOR a 
WHERE a.ID NOT IN 
  (SELECT 
    old_id 
  FROM
    max_test.map_channel_cooperator) ;
-- ALTER TABLE max_test.map_channel_cooperator ADD INDEX (OLD_ID);
END;

