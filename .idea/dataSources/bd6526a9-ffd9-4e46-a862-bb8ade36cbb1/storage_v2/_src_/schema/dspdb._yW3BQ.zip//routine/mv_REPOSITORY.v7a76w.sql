create
    definer = hemp@`%` procedure mv_REPOSITORY()
BEGIN
TRUNCATE TABLE dspdb.REPOSITORY;
-- 中间表到货包数
-- DROP TABLE IF EXISTS max_test.sg_arrival_ext_bak;
-- CREATE TABLE max_test.sg_arrival_ext_bak
truncate table max_test.sg_arrival_ext_bak;
insert into max_test.sg_arrival_ext_bak
SELECT T1.* FROM
(SELECT
   a.id
  ,a.OPPORTUNITY_ID
  ,a.ARRIVAL_STATUS
  ,a.ARRIVAL_COUNT
  ,a.COMMENT
  ,a.SENG_OUT_DATE
  ,a.ARRIVAL_DATE
FROM sm_zy.sg_arrival_ext a
ORDER BY a.OPPORTUNITY_ID
        ,CASE WHEN a.ARRIVAL_STATUS='已到货' THEN 1
              WHEN a.ARRIVAL_STATUS='部分到货' THEN 2
              WHEN a.ARRIVAL_STATUS='未到货' THEN 3
              END
        ,a.ARRIVAL_DATE DESC) T1
GROUP BY T1.OPPORTUNITY_ID;
-- 索引
-- create index sg_arrival_ext_bak_OPPORTUNITY_ID on max_test.sg_arrival_ext_bak(OPPORTUNITY_ID);
-- create index sg_opportunities_OPPORTUNITY_ID on sm_zy.sg_opportunities(OPPORTUNITY_ID);
-- 新建中间表（司米仓库）
-- DROP TABLE IF EXISTS max_test.REPOSITORY_bak;
-- CREATE TABLE max_test.REPOSITORY_bak
-- 正单
truncate table max_test.REPOSITORY_bak;
insert into max_test.REPOSITORY_bak
SELECT
   a.OPPORTUNITY_ID AS OPPORTUNITY_ID
  ,REPLACE(UUID(),'-','') AS ID                                   -- 主键
  ,NULL AS SERVICE_ORDER_ID                                       -- 工单ID
  ,NULL AS SERVICE_ORDER_NO                                       -- 工单编号
  ,'SCHMIDT' AS BRAND                                             -- 品牌（索菲亚、司米、米兰纳）                          
  ,a.OPPORTUNITY_ID AS BRAND_ORDER_ID                             -- 品牌单ID                                              
  ,a.SYS_GEN_ORDNUM AS BRAND_ORDER_NO                             -- 品牌单编号                                            
  ,a.SYS_GEN_ORDNUM AS ORDER_NO                                   -- 单号(工单号+品牌单号)                                 
  ,'ORDER' AS ORDER_TYPE                                          -- 单类型                                                
  ,c.NEW_ID AS CUSTOMER_ID                                        -- 客户ID                                                
  ,c.NEW_PHONE AS CUSTOMER_MOBILE                                 -- 客户电话                                              
  ,c.NEW_NAME AS CUSTOMER_NAME                                    -- 客户姓名                                              
  ,'PLAN' AS SOURCE                                               -- 数据来源:工单(SERVICE_ORDER),物流(DELIVERY),计划(PLAN)
  ,house.ID AS HOUSE_ID                                           -- 家庭住址ID
  ,house.CITY AS CITY                                             -- 市
  ,house.AREA AS AREA                                             -- 区
  ,house.ADDR AS ADDR                                             -- 地址
  ,0 AS LONGITUDE                                                 -- 经度
  ,0 AS LATITUDE                                                  -- 纬度
  ,NULL AS LOCATION                                               -- 定位地址
  ,COALESCE(t2.TAKE_TIME,t5.TAKE_TIME,a.PRODUCE,PRODUCED) AS SHIPPING_DATE         -- 出货日期
  ,COALESCE(t2.DELIVERY_TIME,t5.DELIVERY_TIME,a.DELIVERY_DATE) AS DELIVERY_DATE    -- 送货日期
  ,COALESCE(t2.INSTALL_TIME,t5.INSTALL_TIME,a.EXECUTE,a.EXECUTED) AS INSTALL_DATE  -- 安装日期
  ,CASE WHEN t6.ARRIVAL_STATUS='已到货' THEN 'ALL_ARRIVE'
        WHEN t6.ARRIVAL_STATUS='部分到货' THEN 'PART_ARRIVE'
        ELSE 'NOT_ARRIVE'
        END AS ARRIVE_STATUS                                      -- 到货状态:未到货,部分到货,已到货 
  ,CASE WHEN t6.ARRIVAL_STATUS='已到货' THEN 'REPOSITORY_IN'
        ELSE 'REPOSITORY_NOT_IN'
        END AS INVENTORY_STATUS                                   -- 库存状态:未入库,已入库,已出库  
  ,CASE WHEN t6.ARRIVAL_STATUS='已到货' THEN t6.ARRIVAL_COUNT
        WHEN t6.ARRIVAL_STATUS='部分到货' THEN t6.ARRIVAL_COUNT
        ELSE 0
        END AS SHOULD_PACKAGE_QTY                                 -- 应到包数                       
  ,CASE WHEN t6.ARRIVAL_STATUS='已到货' THEN t6.ARRIVAL_COUNT
        WHEN t6.ARRIVAL_STATUS='部分到货' THEN t6.ARRIVAL_COUNT
        ELSE 0
        END AS REAL_PACKAGE_QTY                                   -- 实到包数                       
  ,'WHOLE' AS SHIPMENT                                            -- 出货状态（出货方式）           
  ,'THIRD_ARTY' AS DELIVER_METHOD                                 -- 送货方式:第三方车队,金杯       
  ,e.VERIFYDATE AS FACTORY_DATE                                   -- 下单工厂日期                   
  ,IFNULL(i.new_id,'999999999') AS CREATOR_ORG_ID                 -- 创建人所属门店ID               
  ,i.new_name AS ORG_NAME                                         -- 所属门店名称                   
  ,'' AS REMARK                                                   -- 备注                           
  ,IFNULL(a.CREATION_DATE,SYSDATE()) AS GMT_CREATE                -- 创建时间                       
  ,IFNULL(f.new_id,'999999999') AS CREATOR_ID                     -- 创建人                         
  ,IFNULL(a.LAST_UPDATE_DATE,SYSDATE()) AS GMT_MODIFIED           -- 更新时间                       
  ,IFNULL(g.new_id,'999999999') AS MODIFIED_USER_ID               -- 更新人                         
FROM sm_zy.sg_opportunities a
JOIN max_test.MAP_CUSTOMER c ON a.CUSTOMER_ID=c.old_id
LEFT JOIN max_test.MAP_HOUSE_ID hc ON c.NEW_ID=hc.CUSTOMER_ID AND a.OPPORTUNITY_ID=hc.OLD_ID
LEFT JOIN dspdb.`CUST_HOUSE` house ON hc.new_id=house.ID
LEFT JOIN sm_zy.dms_plan_info d ON a.OPPORTUNITY_ID=d.BILL_ID
LEFT JOIN sm_zy.dms_opportunities_ext e ON a.OPPORTUNITY_ID=e.OPPORTUNITY_ID
LEFT JOIN max_test.map_emp f ON a.CREATED_BY=f.old_id
LEFT JOIN max_test.map_emp g ON a.LAST_UPDATED_BY=g.old_id
LEFT JOIN sm_zy.sg_user h ON a.CREATED_BY=h.USER_ID
LEFT JOIN max_test.map_org i ON h.ORG_ID=i.old_id AND i.source IN ('sm_zy','')
LEFT JOIN sm_zy.dms_plan_info t2 ON a.OPPORTUNITY_ID=t2.BILL_ID
LEFT JOIN (SELECT * FROM (SELECT * FROM sm_zy.sg_installbill ORDER BY ACTUAL_INSTALL_DATE DESC) a GROUP BY a.OPPORTUNITY_ID) t3 ON a.OPPORTUNITY_ID=t3.OPPORTUNITY_ID
LEFT JOIN (SELECT * FROM sm_zy.dms_transport_task GROUP BY bill_id) t4 ON t3.OPPORTUNITY_ID=t4.BILL_ID
LEFT JOIN (SELECT DISTINCT bill_id,TAKE_TIME,DELIVERY_TIME,INSTALL_TIME FROM sm_zy.dms_transport_task
           WHERE DELIVERY_STATE NOT IN ('retreat','retreatPlan','alreadyCancel','alreadyTransfer')) t5 ON a.OPPORTUNITY_ID=t5.BILL_ID
LEFT JOIN max_test.sg_arrival_ext_bak t6 ON a.OPPORTUNITY_ID=t6.OPPORTUNITY_ID
WHERE a.CURRENT_STATUS='PRODUCED' AND SUBSTR(a.SYS_GEN_ORDNUM,1,1)='C';
-- 增补单
INSERT INTO max_test.REPOSITORY_bak
SELECT
   a.OPPORTUNITY_ID AS OPPORTUNITY_ID
  ,REPLACE(UUID(),'-','') AS ID                                   -- 主键
  ,NULL AS SERVICE_ORDER_ID                                       -- 工单ID
  ,NULL AS SERVICE_ORDER_NO                                       -- 工单编号
  ,'SCHMIDT' AS BRAND                                             -- 品牌（索菲亚、司米、米兰纳）                          
  ,a.OPPORTUNITY_ID AS BRAND_ORDER_ID                             -- 品牌单ID                                              
  ,a.SYS_GEN_ORDNUM AS BRAND_ORDER_NO                             -- 品牌单编号                                            
  ,a.SYS_GEN_ORDNUM AS ORDER_NO                                   -- 单号(工单号+品牌单号)                                 
  ,'SUPPLEMENT' AS ORDER_TYPE                                     -- 单类型                                                
  ,c.NEW_ID AS CUSTOMER_ID                                        -- 客户ID                                                
  ,c.NEW_PHONE AS CUSTOMER_MOBILE                                 -- 客户电话                                              
  ,c.NEW_NAME AS CUSTOMER_NAME                                    -- 客户姓名                                              
  ,'PLAN' AS SOURCE                                               -- 数据来源:工单(SERVICE_ORDER),物流(DELIVERY),计划(PLAN)
  ,house.ID AS HOUSE_ID                                           -- 家庭住址ID
  ,house.CITY AS CITY                                             -- 市
  ,house.AREA AS AREA                                             -- 区
  ,house.ADDR AS ADDR                                             -- 地址
  ,0 AS LONGITUDE                                                 -- 经度
  ,0 AS LATITUDE                                                  -- 纬度
  ,NULL AS LOCATION                                               -- 定位地址
  ,COALESCE(t2.TAKE_TIME,t5.TAKE_TIME,a.PRODUCE,PRODUCED) AS SHIPPING_DATE         -- 出货日期
  ,COALESCE(t2.DELIVERY_TIME,t5.DELIVERY_TIME,a.DELIVERY_DATE) AS DELIVERY_DATE    -- 送货日期
  ,COALESCE(t2.INSTALL_TIME,t5.INSTALL_TIME,a.EXECUTE,a.EXECUTED) AS INSTALL_DATE  -- 安装日期
  ,CASE WHEN t6.ARRIVAL_STATUS='已到货' THEN 'ALL_ARRIVE'
        WHEN t6.ARRIVAL_STATUS='部分到货' THEN 'PART_ARRIVE'
        ELSE 'NOT_ARRIVE'
        END AS ARRIVE_STATUS                                      -- 到货状态:未到货,部分到货,已到货 
  ,CASE WHEN t6.ARRIVAL_STATUS='已到货' THEN 'REPOSITORY_IN'
        ELSE 'REPOSITORY_NOT_IN'
        END AS INVENTORY_STATUS                                   -- 库存状态:未入库,已入库,已出库  
  ,CASE WHEN t6.ARRIVAL_STATUS='已到货' THEN t6.ARRIVAL_COUNT
        WHEN t6.ARRIVAL_STATUS='部分到货' THEN t6.ARRIVAL_COUNT
        ELSE 0
        END AS SHOULD_PACKAGE_QTY                                 -- 应到包数                       
  ,CASE WHEN t6.ARRIVAL_STATUS='已到货' THEN t6.ARRIVAL_COUNT
        WHEN t6.ARRIVAL_STATUS='部分到货' THEN t6.ARRIVAL_COUNT
        ELSE 0
        END AS REAL_PACKAGE_QTY                                   -- 实到包数                       
  ,'WHOLE' AS SHIPMENT                                            -- 出货状态（出货方式）           
  ,'THIRD_ARTY' AS DELIVER_METHOD                                 -- 送货方式:第三方车队,金杯       
  ,e.VERIFYDATE AS FACTORY_DATE                                   -- 下单工厂日期                   
  ,IFNULL(i.new_id,'999999999') AS CREATOR_ORG_ID                 -- 创建人所属门店ID               
  ,i.new_name AS ORG_NAME                                         -- 所属门店名称                   
  ,'' AS REMARK                                                   -- 备注                           
  ,IFNULL(a.CREATION_DATE,SYSDATE()) AS GMT_CREATE                -- 创建时间                       
  ,IFNULL(f.new_id,'999999999') AS CREATOR_ID                     -- 创建人                         
  ,IFNULL(a.LAST_UPDATE_DATE,SYSDATE()) AS GMT_MODIFIED           -- 更新时间                       
  ,IFNULL(g.new_id,'999999999') AS MODIFIED_USER_ID               -- 更新人                         
FROM sm_zy.sg_opportunities a
JOIN max_test.MAP_CUSTOMER c ON a.CUSTOMER_ID=c.old_id
LEFT JOIN max_test.MAP_HOUSE_ID hc ON c.NEW_ID=hc.CUSTOMER_ID AND a.OPPORTUNITY_ID=hc.OLD_ID
LEFT JOIN dspdb.`CUST_HOUSE` house ON hc.new_id=house.ID
LEFT JOIN sm_zy.dms_plan_info d ON a.OPPORTUNITY_ID=d.BILL_ID
LEFT JOIN sm_zy.dms_opportunities_ext e ON a.OPPORTUNITY_ID=e.OPPORTUNITY_ID
LEFT JOIN max_test.map_emp f ON a.CREATED_BY=f.old_id
LEFT JOIN max_test.map_emp g ON a.LAST_UPDATED_BY=g.old_id
LEFT JOIN sm_zy.sg_user h ON a.CREATED_BY=h.USER_ID
LEFT JOIN max_test.map_org i ON h.ORG_ID=i.old_id AND i.source IN ('sm_zy','')
LEFT JOIN sm_zy.dms_plan_info t2 ON a.OPPORTUNITY_ID=t2.BILL_ID
LEFT JOIN (SELECT * FROM (SELECT * FROM sm_zy.sg_installbill ORDER BY ACTUAL_INSTALL_DATE DESC) a GROUP BY a.OPPORTUNITY_ID) t3 ON a.OPPORTUNITY_ID=t3.OPPORTUNITY_ID
LEFT JOIN (SELECT * FROM sm_zy.dms_transport_task GROUP BY bill_id) t4 ON t3.OPPORTUNITY_ID=t4.BILL_ID
LEFT JOIN (SELECT DISTINCT bill_id,TAKE_TIME,DELIVERY_TIME,INSTALL_TIME FROM sm_zy.dms_transport_task
           WHERE DELIVERY_STATE NOT IN ('retreat','retreatPlan','alreadyCancel','alreadyTransfer')) t5 ON a.OPPORTUNITY_ID=t5.BILL_ID
LEFT JOIN max_test.sg_arrival_ext_bak t6 ON a.OPPORTUNITY_ID=t6.OPPORTUNITY_ID
WHERE a.CURRENT_STATUS='PRODUCED' AND SUBSTR(a.SYS_GEN_ORDNUM,1,3)='ZBC';
-- 插数进目标表
INSERT INTO dspdb.REPOSITORY
SELECT
   a.ID
  ,a.SERVICE_ORDER_ID
  ,a.SERVICE_ORDER_NO
  ,a.BRAND
  ,a.BRAND_ORDER_ID
  ,a.BRAND_ORDER_NO
  ,a.ORDER_NO
  ,a.ORDER_TYPE
  ,a.CUSTOMER_ID
  ,a.CUSTOMER_MOBILE
  ,a.CUSTOMER_NAME
  ,a.SOURCE
  ,a.HOUSE_ID
  ,a.CITY
  ,a.AREA
  ,a.ADDR
  ,a.LONGITUDE
  ,a.LATITUDE
  ,a.LOCATION
  ,IFNULL(a.SHIPPING_DATE,DATE_SUB(a.DELIVERY_DATE,INTERVAL 1 DAY))
  ,a.DELIVERY_DATE
  ,a.INSTALL_DATE
  ,a.ARRIVE_STATUS
  ,a.INVENTORY_STATUS
  ,a.SHOULD_PACKAGE_QTY
  ,a.REAL_PACKAGE_QTY
  ,a.SHIPMENT
  ,a.DELIVER_METHOD
  ,a.FACTORY_DATE
  ,a.CREATOR_ORG_ID
  ,a.ORG_NAME
  ,a.REMARK
  ,a.GMT_CREATE
  ,a.CREATOR_ID
  ,a.GMT_MODIFIED
  ,a.MODIFIED_USER_ID
FROM max_test.REPOSITORY_bak a;
-- 删除中间表
-- drop table if exists max_test.REPOSITORY_bak;
-- DROP TABLE IF EXISTS max_test.sg_arrival_ext_bak;
    END;

