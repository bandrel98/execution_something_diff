create
    definer = weng@`%` procedure create_orgnazition_tag(IN tag varchar(50), IN tagName varchar(100))
BEGIN
  #添加标签的ID
  DECLARE tagId VARCHAR(36);
  #用于判断是否结束循环
  DECLARE done INT DEFAULT 0; 
  #绑定关系表id
  DECLARE relationId VARCHAR(36);
  #组织机构的id
  DECLARE orgId VARCHAR(36);
  SELECT REPLACE(UUID(), '-', '') INTO tagId;
  CASE tag
    WHEN "P_SHOP"
      THEN 
        #添加内置标签
        INSERT INTO `SYS_TAG` VALUES (tagId, 'ORGANIZATION', tag, tagName, NULL, 1);
        #绑定标签
        INSERT INTO SYS_TAG_BINDING (ID, REALM, ENTITY_ID, TAG_ID) 
          SELECT
            ID AS ID,
            "ORGANIZATION" AS REALM,
            ID AS ENTITY_ID,
            CONCAT(tagId) AS TAG_ID
          FROM
            DEALER_ORGANIZATION
          WHERE
            SOGAL_CODE IS NOT NULL
          AND SCHMIDT_CODE IS NOT NULL
          AND MILANA_CODE IS NOT NULL
          AND VALID = TRUE;
    WHEN "SHOP"
      THEN 
        #添加内置标签
        INSERT INTO `SYS_TAG` VALUES (tagId, 'ORGANIZATION', tag, tagName, NULL, 1);
        #绑定标签
        INSERT INTO SYS_TAG_BINDING (ID, REALM, ENTITY_ID, TAG_ID) 
          SELECT 
            ID AS ID,
            "ORGANIZATION" AS REALM,
            ID AS ENTITY_ID,
            CONCAT(tagId) AS TAG_ID
          FROM 
            DEALER_ORGANIZATION org
          WHERE
            org.ID NOT IN (SELECT ID FROM DEALER_ORGANIZATION WHERE SOGAL_CODE IS NULL AND SCHMIDT_CODE IS NULL AND MILANA_CODE IS NULL AND VALID = TRUE)
          AND org.ID NOT IN (SELECT ID FROM DEALER_ORGANIZATION WHERE SOGAL_CODE IS NOT NULL AND SCHMIDT_CODE IS NOT NULL AND MILANA_CODE IS NOT NULL AND VALID = TRUE)
          AND VALID = TRUE;
    WHEN "DEPARTMENT"
      THEN 
        #添加内置标签
        INSERT INTO `SYS_TAG` VALUES (tagId, 'ORGANIZATION', tag, tagName, NULL, 1);
        #绑定标签
        INSERT INTO SYS_TAG_BINDING (ID, REALM, ENTITY_ID, TAG_ID) 
          SELECT
            ID AS ID,
            "ORGANIZATION" AS REALM,
            ID AS ENTITY_ID,
            CONCAT(tagId) AS TAG_ID
          FROM
            DEALER_ORGANIZATION
          WHERE
            SOGAL_CODE IS NULL
          AND SCHMIDT_CODE IS NULL
          AND MILANA_CODE IS NULL
          AND VALID = TRUE;
  END CASE;
  #修改id为uuid
  UPDATE SYS_TAG_BINDING SET ID = REPLACE(UUID(), '-', '') WHERE REALM = "ORGANIZATION";
END;

