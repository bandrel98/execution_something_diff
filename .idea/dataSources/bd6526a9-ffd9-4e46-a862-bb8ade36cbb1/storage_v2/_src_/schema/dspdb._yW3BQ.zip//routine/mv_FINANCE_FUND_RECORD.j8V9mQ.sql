create
    definer = hemp@`%` procedure mv_FINANCE_FUND_RECORD()
BEGIN
TRUNCATE TABLE dspdb.FINANCE_FUND_RECORD;
-- DELETE FROM dspdb.FINANCE_FUND_RECORD where ACTION in ('TRANSFER','PAYMENT','REFUND','ORDERS');
-- 转账 索菲亚
INSERT INTO dspdb.FINANCE_FUND_RECORD
-- 转账 索菲亚
SELECT  REPLACE(UUID(),'-','') AS ID  
         ,IFNULL(mc0.`NEW_ID`,'') AS CUST_ID #转入客户ID
         ,'TRANSFER', 'IN'
         ,CASE WHEN state = "1"                           THEN "PROCESSING"
               WHEN state = "2" AND EXECUTION_STATE = "1" THEN "PROCESSING"
               WHEN state = "2" AND EXECUTION_STATE = '2' THEN "SUCCEED"
               WHEN state = "3"                           THEN "FAILED"
               WHEN                 EXECUTION_STATE = "3" THEN "FAILED"  
          END                                AS STATUS
         ,ORDER_TRANSFERRED_AMOUNT           AS AMOUNT
         ,'TRANSFER'                         AS REALM
         ,TRANSFER_VOUCHER_ID                AS REALM_ID 
         ,IFNULL(me.new_id,SINGLE_PLAYER)    AS CREATOR_ID
         ,IFNULL(U.`NAME`,'人员未明')        AS CREATOR_NAME
         ,SYSTEMSINGLE_DATE                  AS TIME_CREATED 
         ,IFNULL(me1.new_id,IFNULL(U1.USER_ID,RECENT_OPERATOR)) AS LAST_UPDATED_BY
         ,RECENT_OPERATING_TIME              AS LAST_UPDATE_TIME 
 FROM sogaldb.DMS_MD_VOUCHERINFO V
 LEFT JOIN sogaldb.`SG_USER` U  ON V.SINGLE_PLAYER=U.USER_ID 
 LEFT JOIN sogaldb.`SG_USER` U1 ON V.RECENT_OPERATOR=U1.PHONE
 LEFT JOIN max_test.`map_emp` me  ON V.SINGLE_PLAYER=me.old_id
 LEFT JOIN max_test.`map_emp` me1 ON U1.USER_ID=me.old_id
 LEFT JOIN max_test.`MAP_CUSTOMER` mc0 ON V.`INTO_CUSTOMER_ID`=mc0.`OLD_ID`
 LEFT JOIN max_test.`MAP_CUSTOMER` mc1 ON V.`OUT_CUSTOMER_ID` =mc1.`OLD_ID`  
 WHERE mc0.NEW_ID IS NOT  NULL 
   AND mc1.NEW_ID IS NOT  NULL   
   AND IFNULL(mc0.`NEW_PHONE`,'')<>IFNULL(mc1.`NEW_PHONE`,'')   
   
UNION ALL
   SELECT  REPLACE(UUID(),'-','') AS ID  
         ,IFNULL(mc1.`NEW_ID`,'') AS CUST_ID #转出客户ID
         ,'TRANSFER', 'OUT'
         ,CASE WHEN state = "1"                           THEN "PROCESSING"
               WHEN state = "2" AND EXECUTION_STATE = "1" THEN "PROCESSING"
               WHEN state = "2" AND EXECUTION_STATE = '2' THEN "SUCCEED"
               WHEN state = "3"                           THEN "FAILED"
               WHEN                 EXECUTION_STATE = "3" THEN "FAILED"  
          END                                AS STATUS
         ,ORDER_TRANSFERRED_AMOUNT           AS AMOUNT
         ,'TRANSFER'                         AS REALM
         ,TRANSFER_VOUCHER_ID                AS REALM_ID 
         ,IFNULL(me.new_id,SINGLE_PLAYER)    AS CREATOR_ID
         ,IFNULL(U.`NAME`,'人员未明')        AS CREATOR_NAME
         ,SYSTEMSINGLE_DATE                  AS TIME_CREATED 
         ,IFNULL(me1.new_id,IFNULL(U1.USER_ID,RECENT_OPERATOR)) AS LAST_UPDATED_BY
         ,RECENT_OPERATING_TIME              AS LAST_UPDATE_TIME 
 FROM sogaldb.DMS_MD_VOUCHERINFO V
 LEFT JOIN sogaldb.`SG_USER` U  ON V.SINGLE_PLAYER=U.USER_ID 
 LEFT JOIN sogaldb.`SG_USER` U1 ON V.RECENT_OPERATOR=U1.PHONE
 LEFT JOIN max_test.`map_emp` me  ON V.SINGLE_PLAYER=me.old_id
 LEFT JOIN max_test.`map_emp` me1 ON U1.USER_ID=me.old_id
 LEFT JOIN max_test.`MAP_CUSTOMER` mc0 ON V.`INTO_CUSTOMER_ID`=mc0.`OLD_ID`
 LEFT JOIN max_test.`MAP_CUSTOMER` mc1 ON V.`OUT_CUSTOMER_ID` =mc1.`OLD_ID`  
 WHERE mc0.NEW_ID IS NOT  NULL 
   AND mc1.NEW_ID IS NOT   NULL 
   AND IFNULL(mc0.`NEW_PHONE`,'')<>IFNULL(mc1.`NEW_PHONE`,'')  
 ; 
-- 转账 司米
INSERT INTO dspdb.FINANCE_FUND_RECORD
SELECT  REPLACE(UUID(),'-','') AS ID  
         ,IFNULL(mc0.`NEW_ID`,'') AS CUST_ID #转入客户ID
         ,'TRANSFER', 'IN'
         ,CASE WHEN state = "1"                           THEN "PROCESSING"
               WHEN state = "2" AND EXECUTION_STATE = "1" THEN "PROCESSING"
               WHEN state = "2" AND EXECUTION_STATE = '2' THEN "SUCCEED"
               WHEN state = "3"                           THEN "FAILED"
               WHEN                 EXECUTION_STATE = "3" THEN "FAILED"  
          END                                AS STATUS
         ,ORDER_TRANSFERRED_AMOUNT           AS AMOUNT
         ,'TRANSFER'                         AS REALM
         ,TRANSFER_VOUCHER_ID                AS REALM_ID 
         ,IFNULL(me.new_id,SINGLE_PLAYER)    AS CREATOR_ID
         ,IFNULL(U.`NAME`,'人员未明')        AS CREATOR_NAME
         ,SYSTEMSINGLE_DATE                  AS TIME_CREATED 
         ,IFNULL(me1.new_id,IFNULL(U1.USER_ID,RECENT_OPERATOR)) AS LAST_UPDATED_BY
         ,RECENT_OPERATING_TIME              AS LAST_UPDATE_TIME 
 FROM sm_zy.DMS_MD_VOUCHERINFO V
 LEFT JOIN sm_zy.`SG_USER` U  ON V.SINGLE_PLAYER=U.USER_ID 
 LEFT JOIN sm_zy.`SG_USER` U1 ON V.RECENT_OPERATOR=U1.PHONE
 LEFT JOIN max_test.`map_emp` me  ON V.SINGLE_PLAYER=me.old_id
 LEFT JOIN max_test.`map_emp` me1 ON U1.USER_ID=me.old_id
 LEFT JOIN max_test.`MAP_CUSTOMER` mc0 ON V.`INTO_CUSTOMER_ID`=mc0.`OLD_ID`
 LEFT JOIN max_test.`MAP_CUSTOMER` mc1 ON V.`OUT_CUSTOMER_ID` =mc1.`OLD_ID`  
 WHERE mc0.NEW_ID IS NOT  NULL 
   AND mc1.NEW_ID IS NOT  NULL   
   AND IFNULL(mc0.`NEW_PHONE`,'')<>IFNULL(mc1.`NEW_PHONE`,'')   
   
UNION ALL
   SELECT  REPLACE(UUID(),'-','') AS ID  
         ,IFNULL(mc1.`NEW_ID`,'') AS CUST_ID #转出客户ID
         ,'TRANSFER', 'OUT'
         ,CASE WHEN state = "1"                           THEN "PROCESSING"
               WHEN state = "2" AND EXECUTION_STATE = "1" THEN "PROCESSING"
               WHEN state = "2" AND EXECUTION_STATE = '2' THEN "SUCCEED"
               WHEN state = "3"                           THEN "FAILED"
               WHEN                 EXECUTION_STATE = "3" THEN "FAILED"  
          END                                AS STATUS
         ,ORDER_TRANSFERRED_AMOUNT           AS AMOUNT
         ,'TRANSFER'                         AS REALM
         ,TRANSFER_VOUCHER_ID                AS REALM_ID 
         ,IFNULL(me.new_id,SINGLE_PLAYER)    AS CREATOR_ID
         ,IFNULL(U.`NAME`,'人员未明')        AS CREATOR_NAME
         ,SYSTEMSINGLE_DATE                  AS TIME_CREATED 
         ,IFNULL(me1.new_id,IFNULL(U1.USER_ID,RECENT_OPERATOR)) AS LAST_UPDATED_BY
         ,RECENT_OPERATING_TIME              AS LAST_UPDATE_TIME 
 FROM sm_zy.DMS_MD_VOUCHERINFO V
 LEFT JOIN sm_zy.`SG_USER` U  ON V.SINGLE_PLAYER=U.USER_ID 
 LEFT JOIN sm_zy.`SG_USER` U1 ON V.RECENT_OPERATOR=U1.PHONE
 LEFT JOIN max_test.`map_emp` me  ON V.SINGLE_PLAYER=me.old_id
 LEFT JOIN max_test.`map_emp` me1 ON U1.USER_ID=me.old_id
 LEFT JOIN max_test.`MAP_CUSTOMER` mc0 ON V.`INTO_CUSTOMER_ID`=mc0.`OLD_ID`
 LEFT JOIN max_test.`MAP_CUSTOMER` mc1 ON V.`OUT_CUSTOMER_ID` =mc1.`OLD_ID`  
 WHERE mc0.NEW_ID IS NOT  NULL 
   AND mc1.NEW_ID IS NOT   NULL 
   AND IFNULL(mc0.`NEW_PHONE`,'')<>IFNULL(mc1.`NEW_PHONE`,'')  
 ; 
-- 改补
INSERT INTO dspdb.FINANCE_FUND_RECORD
 SELECT REPLACE(UUID(),'-','') AS ID 
       ,c.`CUSTOMER_ID`       AS CUST_ID 
       ,'MODIFY', 'IN'
       ,CASE WHEN a.IMPLEMENT_STATUS = '1' THEN 'PROCESSING'
             WHEN a.IMPLEMENT_STATUS = '2' THEN 'SUCCEED'
             WHEN a.IMPLEMENT_STATUS = '3' THEN 'FAILED'  
       END                                AS STATUS
       ,a.COLLECT_MONEY   AS AMOUNT
       ,'MODIFY' AS REALM
       ,a.CHANGE_ID AS   REALM_ID 
       
         ,IFNULL(me.new_id,a.CREATED_BY)    AS CREATOR_ID
         ,IFNULL(U.`NAME`,'人员未明')        AS CREATOR_NAME
         ,a.CREATION_DATE AS TIME_CREATED 
         ,IFNULL(me1.new_id,a.LAST_UPDATED_BY) AS LAST_UPDATED_BY
         ,a.LAST_UPDATE_DATE              AS LAST_UPDATE_TIME 
FROM  sogaldb.DMS_CHANGE_COLLECT_RECORD  a
LEFT JOIN sogaldb.DMS_CHANGE_RECORD              b ON b.ID = a.CHANGE_ID
LEFT JOIN sogaldb.SG_OPPORTUNITIES               c ON c.OPPORTUNITY_ID = b.BILL_ID
LEFT JOIN sogaldb.`SG_USER`   U  ON a.CREATED_BY=U.USER_ID 
LEFT JOIN max_test.`map_emp` me  ON a.CREATED_BY=me.old_id
LEFT JOIN max_test.`map_emp` me1 ON a.LAST_UPDATED_BY=me1.old_id
UNION ALL 
SELECT REPLACE(UUID(),'-','') AS ID 
       ,c.`CUSTOMER_ID`       AS CUST_ID 
       ,'MODIFY', 'IN'
       ,CASE WHEN a.IMPLEMENT_STATUS = '1' THEN 'PROCESSING'
             WHEN a.IMPLEMENT_STATUS = '2' THEN 'SUCCEED'
             WHEN a.IMPLEMENT_STATUS = '3' THEN 'FAILED'  
       END                                AS STATUS
       ,a.COLLECT_MONEY   AS AMOUNT
       ,'MODIFY' AS REALM
       ,a.CHANGE_ID AS   REALM_ID 
       
         ,IFNULL(me.new_id,a.CREATED_BY)    AS CREATOR_ID
         ,IFNULL(U.`NAME`,'人员未明')        AS CREATOR_NAME
         ,a.CREATION_DATE AS TIME_CREATED 
         ,IFNULL(me1.new_id,a.LAST_UPDATED_BY) AS LAST_UPDATED_BY
         ,a.LAST_UPDATE_DATE              AS LAST_UPDATE_TIME 
 FROM  sm_zy.dms_change_collect_record  a
LEFT JOIN sm_zy.dms_change_record              b ON b.ID = a.CHANGE_ID
LEFT JOIN sm_zy.sg_opportunities               c ON c.OPPORTUNITY_ID = b.BILL_ID
LEFT JOIN sm_zy.`sg_user`   U  ON a.CREATED_BY=U.USER_ID 
LEFT JOIN max_test.`map_emp` me  ON a.CREATED_BY=me.old_id
LEFT JOIN max_test.`map_emp` me1 ON a.LAST_UPDATED_BY=me1.old_id
;
-- 收款
INSERT INTO dspdb.FINANCE_FUND_RECORD
SELECT
   a.RECORD_ID AS ID                                        -- 资金记录ID
  ,a.CUST_ID AS CUST_ID                                     -- 客户ID
  ,'PAYMENT' AS ACTION                                      -- 资金动作
  ,'IN' AS FLOW                                             -- 资金流向
  ,CASE WHEN a.REVIEW_STATUS='AUDITING' THEN 'PROCESSING'
        WHEN a.REVIEW_STATUS='REJECTED' THEN 'FAILED'
        WHEN a.REVIEW_STATUS='PASSED'   THEN 'SUCCEED'
   END AS STATUS                                            -- 记录状态
  ,IFNULL(a.AMOUNT,0) AS AMOUNT                             -- 动账金额
  ,'PAYMENT' AS REALM                                       -- 记录相关类型
  ,a.TRX_NUM AS REALM_ID                                    -- 相关类型对应ID
  ,a.CREATOR_ID AS CREATOR_ID                               -- 创建人ID
  ,a.CREATOR_NAME AS CREATOR_NAME                           -- 发起人姓名
  ,a.TIME_CREATED AS TIME_CREATED                           -- 创建时间
  ,a.LAST_UPDATED_BY AS LAST_UPDATED_BY                     -- 最后更新人ID
  ,a.LAST_UPDATE_TIME AS LAST_UPDATE_TIME                   -- 最后更新时间
FROM dspdb.FINANCE_PAYMENT a
WHERE a.REVIEW_STATUS != 'PENDING';
-- 退款
INSERT INTO dspdb.FINANCE_FUND_RECORD
SELECT
   a.RECORD_ID AS ID                                        -- 资金记录ID
  ,a.CUST_ID AS CUST_ID                                     -- 客户ID
  ,'REFUND' AS ACTION                                       -- 资金动作
  ,'OUT' AS FLOW                                            -- 资金流向
  ,CASE WHEN a.`STATUS`='AUDITING' THEN 'PROCESSING'
        WHEN a.`STATUS`='REJECTED' THEN 'CANCELED'
        WHEN a.`STATUS`='PASSED'   THEN 'SUCCEED'
        WHEN a.`STATUS`='VOIDED'   THEN 'FAILED'
   END AS STATUS                                            -- 记录状态
  ,IFNULL(a.AMOUNT,0) AS AMOUNT                             -- 动账金额
  ,'REFUND' AS REALM                                        -- 记录相关类型
  ,a.ID AS REALM_ID                                         -- 相关类型对应ID
  ,a.CREATOR_ID AS CREATOR_ID                               -- 创建人ID
  ,a.CREATOR_NAME AS CREATOR_NAME                           -- 发起人姓名
  ,a.TIME_CREATED AS TIME_CREATED                           -- 创建时间
  ,a.LAST_UPDATED_BY AS LAST_UPDATED_BY                     -- 最后更新人ID
  ,a.LAST_UPDATE_TIME AS LAST_UPDATE_TIME                   -- 最后更新时间
FROM dspdb.FINANCE_REFUND a
WHERE a.`STATUS` != 'PENDING';
-- 品牌单
/*
AUTO_CHECKING("自动审图中"),  PROCESSING处理中 冻结
CHECKING("人工审图中"),       PROCESSING处理中 冻结
AUDITING("审价中"),           PROCESSING处理中 冻结
WAIT_CONFIRM("待下单"),
CONFIRMED("已下单"),
WAIT_PLAN("待排计划"),
CONFIRM_ARRIVAL("确认到货"),
WAIT_DELIVERY("待送货"),
WAIT_INSTALL("待安装"),
INSTALLED("已安装"),
INTERVIEWED("已回访"),
*/
INSERT INTO dspdb.FINANCE_FUND_RECORD
SELECT
   REPLACE(UUID(),'-','') AS ID                -- 资金记录ID
  ,a.CUSTOMER_ID AS CUST_ID                    -- 客户ID
  ,'ORDERS' AS ACTION                          -- 资金动作
  ,'OUT' AS FLOW                               -- 资金流向
  ,CASE WHEN a.`STATUS` IN ('AUTO_CHECKING','CHECKING','AUDITING') THEN 'PROCESSING'
        ELSE 'SUCCEED'
   END AS STATUS                               -- 记录状态
  ,IFNULL(a.ACTUAL_AMOUNT,0) AS AMOUNT         -- 动账金额
  ,'SUBMIT_DRAW' AS REALM                      -- 记录相关类型
  ,a.ID AS REALM_ID                            -- 相关类型对应ID
  ,a.CREATOR_ID AS CREATOR_ID                  -- 创建人ID
  ,b.`NAME` AS CREATOR_NAME                    -- 发起人姓名
  ,a.TIME_CREATED AS TIME_CREATED              -- 创建时间
  ,a.LAST_UPDATED_BY AS LAST_UPDATED_BY        -- 最后更新人ID
  ,a.LAST_UPDATE_TIME AS LAST_UPDATE_TIME      -- 最后更新时间
FROM dspdb.ORD_BRAND_ORDER a
LEFT JOIN dspdb.DEALER_EMPLOYEE b ON a.CREATOR_ID=b.ID
-- LEFT JOIN dspdb.ord_order_process_date c ON a.opportunity_id=c.entity_id
WHERE a.`STATUS` IN ('AUTO_CHECKING'
                    ,'CHECKING'
                    ,'AUDITING'
                    ,'WAIT_CONFIRM'
                    ,'CONFIRMED'
                    ,'WAIT_PLAN'
                    ,'CONFIRM_ARRIVAL'
                    ,'WAIT_DELIVERY'
                    ,'WAIT_INSTALL'
                    ,'INSTALLED'
                    ,'INTERVIEWED');
-- 更新品牌单表
-- UPDATE dspdb.ORD_BRAND_ORDER t INNER JOIN dspdb.FINANCE_FUND_RECORD t1 ON t.ID = t1.REALM_ID SET t.CASH_FLOW_ID=t1.ID;
-- 米兰纳木门
insert into dspdb.FINANCE_FUND_RECORD
select
   REPLACE(UUID(),'-','') AS ID                -- 资金记录ID
  ,f.new_id AS CUST_ID                         -- 客户ID
  ,'ORDERS' as ACTION                          -- 资金动作
  ,'OUT' as FLOW                               -- 资金流向
  ,'SUCCEED' as STATUS                         -- 记录状态
  ,ifnull(a.XDAMOUNT,0) as AMOUNT              -- 动账金额
  ,'SUBMIT_DRAW' as REALM                      -- 记录相关类型
  ,a.OPPORTUNITY_ID as REALM_ID                -- 相关类型对应ID
  ,ifnull(c.new_id,'999999999') as CREATOR_ID  -- 创建人ID
  ,ifnull(d.name,'人员未名') as CREATOR_NAME   -- 发起人姓名
  ,a.CREATION_DATE as TIME_CREATED             -- 创建时间
  ,ifnull(e.new_id,'999999999') as LAST_UPDATED_BY -- 最后更新人ID
  ,b.LAST_UPDATE_DATE as LAST_UPDATE_TIME      -- 最后更新时间
from sogaldb.dms_opportunities_ext a
left join sogaldb.sg_opportunities b on a.OPPORTUNITY_ID=b.OPPORTUNITY_ID
left join max_test.map_emp c on b.CREATED_BY=c.old_id
left join dspdb.DEALER_EMPLOYEE d on c.new_id=d.ID
left join max_test.map_emp e on b.LAST_UPDATED_BY=e.old_id
join max_test.map_customer f on b.CUSTOMER_ID=f.old_id
where substr(replace(upper(a.WOOD_NUM),' ',''),1,1)='M'
and a.WOOD_STATUS<>'已退回';
    END;

