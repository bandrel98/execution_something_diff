create
    definer = hemp@`%` procedure mv_FINANCE_FUND_ACCOUNT()
BEGIN
/*
flow='IN' status='SUCCEED'        动账金额=账户金额
flow='OUT' status='SUCCEED'       动账金额=-账户金额
flow='IN' status='PROCESSING'     动账金额=增项金额
floe='OUT' status='PROCESSING'    动账金额=减项金额
可用金额=账户金额 - 减项金额
可下单金额=账户金额 - 减项金额 + 增项金额
不可体现金额 0
*/
TRUNCATE TABLE dspdb.FINANCE_FUND_ACCOUNT;
INSERT INTO dspdb.FINANCE_FUND_ACCOUNT
SELECT
   b.ID
  ,SUM(b.BALANCE) AS BALANCE                                                     -- 账户金额
--  ,SUM(b.BALANCE)-SUM(b.DECREASE_FROZEN) AS AVAILABLE                            -- 可用金额
--  ,SUM(b.BALANCE)-SUM(b.DECREASE_FROZEN)+SUM(b.INCREASE_FROZEN) AS ORDER_AMOUNT  -- 可下单金额
  ,SUM(b.INCREASE_FROZEN) AS INCREASE_FROZEN                                     -- 增项冻结金额
  ,SUM(b.DECREASE_FROZEN) AS DECREASE_FROZEN                                     -- 减项冻结金额
--  ,0 AS UNWITHDRAW
  ,b.LAST_UPDATE_TIME
FROM
(SELECT
   a.CUST_ID AS ID
  ,CASE WHEN a.FLOW='IN' AND a.`STATUS`='SUCCEED' THEN a.AMOUNT
        WHEN a.FLOW='OUT' AND a.`STATUS`='SUCCEED' THEN -a.AMOUNT
        ELSE 0
        END AS BALANCE            -- 账户总额
  ,'' AS AVAILABLE                -- 可用金额
  ,'' AS ORDER_AMOUNT             -- 可下单金额
  ,CASE WHEN a.FLOW='IN' AND a.STATUS='PROCESSING' THEN a.AMOUNT
        ELSE 0
        END AS INCREASE_FROZEN    -- 增项冻结金额
  ,CASE WHEN a.FLOW='OUT' AND a.STATUS='PROCESSING' THEN a.AMOUNT
        ELSE 0
        END AS DECREASE_FROZEN    -- 减项冻结金额
  ,0 AS UNWITHDRAW                -- 不可提现金额
  ,a.LAST_UPDATE_TIME AS LAST_UPDATE_TIME
FROM dspdb.FINANCE_FUND_RECORD a
WHERE a.STATUS IN ('SUCCEED','PROCESSING')) b
where b.ID <> ''
GROUP BY b.ID;
    END;

