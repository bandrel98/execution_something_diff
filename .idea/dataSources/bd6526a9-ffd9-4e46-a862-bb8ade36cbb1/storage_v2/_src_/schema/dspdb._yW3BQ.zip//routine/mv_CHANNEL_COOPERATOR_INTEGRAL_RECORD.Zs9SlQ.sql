create
    definer = hemp@`%` procedure mv_CHANNEL_COOPERATOR_INTEGRAL_RECORD()
BEGIN
-- 中间表
-- DROP TABLE IF EXISTS max_test.`channal_syjf`;
-- CREATE TABLE max_test.`channal_syjf`
-- 索菲亚
TRUNCATE TABLE max_test.`channal_syjf`;
INSERT INTO max_test.`channal_syjf`
SELECT 
  a.ID AS ID,
  a.FILED_ID AS FILED_ID,
  a.create_time AS CREATE_TIME,
  SUM(
    CASE
      WHEN b.OPERATOR_TYPE = '2' 
      THEN - b.INTEGRAL_COUNT 
      ELSE b.INTEGRAL_COUNT 
    END
  ) AS SURPLUS
FROM
  sogaldb.DMS_CUSTOM_INTEGRAL_MANAGER_RECORD a 
  LEFT JOIN sogaldb.DMS_CUSTOM_INTEGRAL_MANAGER_RECORD b 
    ON a.FILED_ID = b.FILED_ID 
    AND b.create_time <= a.create_time 
GROUP BY a.ID,
  a.FILED_ID,
  a.create_time 
ORDER BY a.FILED_ID,
  a.create_time DESC;
INSERT INTO max_test.`channal_syjf`
SELECT 
  a.ID AS ID,
  a.FILED_ID AS FILED_ID,
  a.create_time AS CREATE_TIME,
  SUM(
    CASE
      WHEN b.OPERATOR_TYPE = '2' 
      THEN - b.INTEGRAL_COUNT 
      ELSE b.INTEGRAL_COUNT 
    END
  ) AS SURPLUS
FROM
  sm_zy.dms_custom_integral_manager_record a 
  LEFT JOIN sm_zy.dms_custom_integral_manager_record b 
    ON a.FILED_ID = b.FILED_ID 
    AND b.create_time <= a.create_time 
GROUP BY a.ID,
  a.FILED_ID,
  a.create_time 
ORDER BY a.FILED_ID,
  a.create_time DESC ;
  
-- 索菲亚
TRUNCATE TABLE dspdb.`CHANNEL_COOPERATOR_INTEGRAL_RECORD`;
INSERT INTO dspdb.`CHANNEL_COOPERATOR_INTEGRAL_RECORD`
-- 审批完成的老客户
SELECT -- 214
  IFNULL(a.ID,'') AS ID,                                          -- 主键
  IFNULL(d.ID,'') AS COOPERATOR_ID,                               -- 合作方ID
  CASE WHEN a.OPERATOR_TYPE='1' THEN 'ADD'
       WHEN a.OPERATOR_TYPE='3' THEN 'ADD'
       WHEN a.OPERATOR_TYPE='2' THEN 'DEDUCT'
       WHEN a.OPERATOR_TYPE='4' THEN 'DEDUCT'
       ELSE ''
       END AS TYPE,                                               -- 积分的增加、减少、冻结、换礼等类型
  ABS(IFNULL(a.INTEGRAL_COUNT,0)) AS CHANGE1,                     -- 本次变动积分
  IFNULL(b.SURPLUS,0) AS SURPLUS,                                 -- 本次变动后剩余积分
  NULL AS POST_COMPANY,                                           -- 快递公司
  NULL AS POST_CODE,                                              -- 快递单号
  CASE WHEN c.lp_type='1' THEN '购物卡'
       WHEN c.lp_type='2' THEN '加油卡'
       ELSE NULL
       END AS SUMMARY,                                            -- 1-购物卡;2-加油卡。摘要：如果是积分兑换则记录兑换的礼品名称（名称来源于业务字段），其它则记录积分变动信息
  'PASSED' AS STATUS,                                             -- 积分换礼审批状态
  '999999999' AS CREATOR_ID,                                      -- 创建人（即经手人）
  '人员未名' AS CREATOR_NAME,                                     -- 创建人姓名
  '999999999' AS CREATOR_ORG_ID,                                  -- 创建人所属门店ID
  '所属门店' AS CREATOR_ORG_NAME,                                 -- 创建人当前所属门店，作为固定值保存，不随以后人员调整而变化
  IFNULL(a.CREATE_TIME,SYSDATE()) AS TIME_CREATED,                -- 创建时间
  IFNULL(c.create_time,SYSDATE()) AS CONFIRM_TIME,                -- 积分换礼审批时间（积分兑换时使用）
  '010' AS DEALER_CODE,                                           -- 经销商5位编码
  a.ID,                                                           -- 合作方-积分变更关联id
  1                                                               -- 是否有效:1-有效;0-无效
FROM
  sogaldb.DMS_CUSTOM_INTEGRAL_MANAGER_RECORD a
LEFT JOIN max_test.channal_syjf b ON a.FILED_ID = b.FILED_ID      -- 中间表（计算本次变动后剩余积分数）
AND a.CREATE_TIME = b.CREATE_TIME
LEFT JOIN (SELECT
                 b.PROCESS_INST_ID
                ,b.COOPERATOR_ID
                ,b.LP_TYPE
                ,d.create_time
                ,'PASSED' AS STATUS
            FROM sfy_xt.dms_wf_score_change_cash_ext a
            LEFT JOIN sfy_xt.dms_wf_score_change_cash b ON a.PARENT_ID=b.PK_ID
            LEFT JOIN (SELECT process_inst_id,MAX(create_time) AS create_time FROM sfy_xt.flow_opinions WHERE activity_def_id = "manualActivity6" GROUP BY process_inst_id) d 
            ON b.PROCESS_INST_ID=d.process_inst_id
            LEFT JOIN sfy_xt.sfy_flow_info c ON b.PROCESS_INST_ID=c.process_inst_id
            WHERE c.current_state='7') c ON a.FILED_ID = c.COOPERATOR_ID                             -- 关联协同表，获取摘要字段
INNER JOIN (SELECT ID,TYPE FROM dspdb.CHANNEL_COOPERATOR WHERE TYPE = 'CUSTOMER') d ON a.FILED_ID=d.ID -- 取老客户且审批完成的合作方ID
WHERE c.`STATUS`='PASSED'
GROUP BY a.ID;
-- 非老客户合作方ID 6090
INSERT INTO dspdb.`CHANNEL_COOPERATOR_INTEGRAL_RECORD`
SELECT
  IFNULL(a.ID,'') AS ID,                                          -- 主键
  IFNULL(d.ID,'') AS COOPERATOR_ID,                               -- 合作方ID
  CASE WHEN a.OPERATOR_TYPE='1' THEN 'ADD'
       WHEN a.OPERATOR_TYPE='3' THEN 'ADD'
       WHEN a.OPERATOR_TYPE='2' THEN 'DEDUCT'
       WHEN a.OPERATOR_TYPE='4' THEN 'DEDUCT'
       ELSE ''
       END AS TYPE,                                               -- 积分的增加、减少、冻结、换礼等类型
  ABS(IFNULL(a.INTEGRAL_COUNT,0)) AS CHANGE1,                     -- 本次变动积分
  IFNULL(b.SURPLUS,0) AS SURPLUS,                                 -- 本次变动后剩余积分
  NULL AS POST_COMPANY,                                           -- 快递公司
  NULL AS POST_CODE,                                              -- 快递单号
  NULL AS SUMMARY,                                                -- 1-购物卡;2-加油卡。摘要：如果是积分兑换则记录兑换的礼品名称（名称来源于业务字段），其它则记录积分变动信息
  'PASSED' AS STATUS,                                             -- 积分换礼审批状态
  '999999999' AS CREATOR_ID,                                      -- 创建人（即经手人）
  '人员未名' AS CREATOR_NAME,                                     -- 创建人姓名
  '999999999' AS CREATOR_ORG_ID,                                  -- 创建人所属门店ID
  '所属门店' AS CREATOR_ORG_NAME,                                 -- 创建人当前所属门店，作为固定值保存，不随以后人员调整而变化
  IFNULL(a.CREATE_TIME,SYSDATE()) AS TIME_CREATED,                -- 创建时间
  SYSDATE() AS CONFIRM_TIME,                                      -- 积分换礼审批时间（积分兑换时使用）
  '010' AS DEALER_CODE,                                           -- 经销商5位编码
  a.ID,                                                           -- 合作方-积分变更关联id
  1                                                               -- 是否有效:1-有效;0-无效
FROM
  sogaldb.DMS_CUSTOM_INTEGRAL_MANAGER_RECORD a
LEFT JOIN max_test.channal_syjf b ON a.FILED_ID = b.FILED_ID      -- 中间表（计算本次变动后剩余积分数）
AND a.CREATE_TIME = b.CREATE_TIME
/*
LEFT JOIN (SELECT
                 b.PROCESS_INST_ID
                ,b.COOPERATOR_ID
                ,b.LP_TYPE
                ,d.create_time
                ,'PASSED' AS STATUS
            FROM sfy_xt.dms_wf_score_change_cash_ext a
            LEFT JOIN sfy_xt.dms_wf_score_change_cash b ON a.PARENT_ID=b.PK_ID
            LEFT JOIN (SELECT process_inst_id,MAX(create_time) AS create_time FROM sfy_xt.flow_opinions WHERE activity_def_id = "manualActivity6" GROUP BY process_inst_id) d 
            ON b.PROCESS_INST_ID=d.process_inst_id
            LEFT JOIN sfy_xt.sfy_flow_info c ON b.PROCESS_INST_ID=c.process_inst_id
            WHERE c.current_state='7') c ON a.FILED_ID = c.COOPERATOR_ID                              -- 关联协同表，获取摘要字段
*/
INNER JOIN (SELECT ID,TYPE FROM dspdb.CHANNEL_COOPERATOR WHERE TYPE <> 'CUSTOMER') d ON a.FILED_ID=d.ID -- 取非老客户多种状态合作方ID
-- WHERE d.ID is not null
GROUP BY
  a.ID;
  
  
-- 司米 0
INSERT INTO dspdb.`CHANNEL_COOPERATOR_INTEGRAL_RECORD`
SELECT
  IFNULL(a.ID,'') AS ID,                                          -- 主键
  IFNULL(d.ID,'') AS COOPERATOR_ID,                               -- 合作方ID
  CASE WHEN a.OPERATOR_TYPE='1' THEN 'ADD'
       WHEN a.OPERATOR_TYPE='3' THEN 'ADD'
       WHEN a.OPERATOR_TYPE='2' THEN 'DEDUCT'
       WHEN a.OPERATOR_TYPE='4' THEN 'DEDUCT'
       ELSE ''
       END AS TYPE,                                               -- 积分的增加、减少、冻结、换礼等类型
  ABS(IFNULL(a.INTEGRAL_COUNT,0)) AS CHANGE1,                     -- 本次变动积分
  IFNULL(b.SURPLUS,0) AS SURPLUS,                                 -- 本次变动后剩余积分
  NULL AS POST_COMPANY,                                           -- 快递公司
  NULL AS POST_CODE,                                              -- 快递单号
  CASE WHEN c.lp_type='1' THEN '购物卡'
       WHEN c.lp_type='2' THEN '加油卡'
       ELSE ''
       END AS SUMMARY,                                            -- 1-购物卡;2-加油卡。摘要：如果是积分兑换则记录兑换的礼品名称（名称来源于业务字段），其它则记录积分变动信息
  'PASSED' AS STATUS,                                             -- 积分换礼审批状态
  '999999999' AS CREATOR_ID,                                      -- 创建人（即经手人）
  '人员未名' AS CREATOR_NAME,                                     -- 创建人姓名
  '999999999' AS CREATOR_ORG_ID,                                  -- 创建人所属门店ID
  '所属门店' AS CREATOR_ORG_NAME,                                 -- 创建人当前所属门店，作为固定值保存，不随以后人员调整而变化
  IFNULL(a.CREATE_TIME,SYSDATE()) AS TIME_CREATED,                -- 创建时间
  IFNULL(c.create_time,SYSDATE()) AS CONFIRM_TIME,                -- 积分换礼审批时间（积分兑换时使用）
  '010' AS DEALER_CODE,                                           -- 经销商5位编码
  a.ID,                                                           -- 合作方-积分变更关联id
  1                                                               -- 是否有效:1-有效;0-无效
FROM
  sm_zy.dms_custom_integral_manager_record a
LEFT JOIN max_test.channal_syjf b ON a.FILED_ID = b.FILED_ID      -- 中间表（计算本次变动后剩余积分数）
AND a.CREATE_TIME = b.CREATE_TIME
LEFT JOIN (SELECT
                 b.PROCESS_INST_ID
                ,b.COOPERATOR_ID
                ,b.LP_TYPE
                ,d.create_time
                ,'PASSED' AS STATUS
           FROM sm_xt.dms_wf_score_change_cash_ext a
           LEFT JOIN sm_xt.dms_wf_score_change_cash b ON a.PARENT_ID=b.PK_ID
           LEFT JOIN (SELECT process_inst_id,MAX(create_time) AS create_time FROM sm_xt.flow_opinions WHERE activity_def_id = "manualActivity6" GROUP BY process_inst_id) d 
           ON b.PROCESS_INST_ID=d.process_inst_id
           LEFT JOIN sm_xt.sfy_flow_info c ON b.PROCESS_INST_ID=c.process_inst_id
           WHERE c.current_state='7') c ON a.FILED_ID = c.COOPERATOR_ID                              -- 关联协同表，获取摘要字段
INNER JOIN (SELECT ID,TYPE FROM dspdb.CHANNEL_COOPERATOR WHERE TYPE = 'CUSTOMER') d ON a.FILED_ID=d.ID -- 取老客户且审批完成的合作方ID
WHERE c.`STATUS`='PASSED'
GROUP BY a.ID;
-- 司米非老客户合作方 1305
INSERT INTO dspdb.`CHANNEL_COOPERATOR_INTEGRAL_RECORD`
SELECT
  IFNULL(a.ID,'') AS ID,                                          -- 主键
  IFNULL(d.ID,'') AS COOPERATOR_ID,                               -- 合作方ID
  CASE WHEN a.OPERATOR_TYPE='1' THEN 'ADD'
       WHEN a.OPERATOR_TYPE='3' THEN 'ADD'
       WHEN a.OPERATOR_TYPE='2' THEN 'DEDUCT'
       WHEN a.OPERATOR_TYPE='4' THEN 'DEDUCT'
       ELSE ''
       END AS TYPE,                                               -- 积分的增加、减少、冻结、换礼等类型
  ABS(IFNULL(a.INTEGRAL_COUNT,0)) AS CHANGE1,                     -- 本次变动积分
  IFNULL(b.SURPLUS,0) AS SURPLUS,                                 -- 本次变动后剩余积分
  NULL AS POST_COMPANY,                                           -- 快递公司
  NULL AS POST_CODE,                                              -- 快递单号
  NULL AS SUMMARY,                                                -- 1-购物卡;2-加油卡。摘要：如果是积分兑换则记录兑换的礼品名称（名称来源于业务字段），其它则记录积分变动信息
  'PASSED' AS STATUS,                                             -- 积分换礼审批状态
  '999999999' AS CREATOR_ID,                                      -- 创建人（即经手人）
  '人员未名' AS CREATOR_NAME,                                     -- 创建人姓名
  '999999999' AS CREATOR_ORG_ID,                                  -- 创建人所属门店ID
  '所属门店' AS CREATOR_ORG_NAME,                                 -- 创建人当前所属门店，作为固定值保存，不随以后人员调整而变化
  IFNULL(a.CREATE_TIME,SYSDATE()) AS TIME_CREATED,                -- 创建时间
  SYSDATE() AS CONFIRM_TIME,                                      -- 积分换礼审批时间（积分兑换时使用）
  '010' AS DEALER_CODE,                                           -- 经销商5位编码
  a.ID,                                                           -- 合作方-积分变更关联id
  1                                                               -- 是否有效:1-有效;0-无效
FROM
  sm_zy.dms_custom_integral_manager_record a
LEFT JOIN max_test.channal_syjf b ON a.FILED_ID = b.FILED_ID      -- 中间表（计算本次变动后剩余积分数）
AND a.CREATE_TIME = b.CREATE_TIME
/*
LEFT JOIN (SELECT
                 b.PROCESS_INST_ID
                ,b.COOPERATOR_ID
                ,b.LP_TYPE
                ,d.create_time
                ,'PASSED' AS STATUS
           FROM sm_xt.dms_wf_score_change_cash_ext a
           LEFT JOIN sm_xt.dms_wf_score_change_cash b ON a.PARENT_ID=b.PK_ID
           LEFT JOIN (SELECT process_inst_id,MAX(create_time) AS create_time FROM sm_xt.flow_opinions WHERE activity_def_id = "manualActivity6" GROUP BY process_inst_id) d 
           ON b.PROCESS_INST_ID=d.process_inst_id
           LEFT JOIN sm_xt.sfy_flow_info c ON b.PROCESS_INST_ID=c.process_inst_id
           WHERE c.current_state='7') c ON a.FILED_ID = c.COOPERATOR_ID                               -- 关联协同表，获取摘要字段
*/
INNER JOIN (SELECT ID,TYPE FROM dspdb.CHANNEL_COOPERATOR WHERE TYPE <> 'CUSTOMER') d ON a.FILED_ID=d.ID -- 取非老客户多种状态合作方ID
-- WHERE d.ID is not null
GROUP BY
  a.ID;
    END;

