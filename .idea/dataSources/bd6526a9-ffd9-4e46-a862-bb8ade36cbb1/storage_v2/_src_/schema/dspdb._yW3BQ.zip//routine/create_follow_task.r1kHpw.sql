create
    definer = weng@`%` procedure create_follow_task()
begin
	#Routine body goes here ...
	#用于判断是否结束循环
	declare done int default 0; 
	#创建任务的id
	declare taskId varchar(36);
	declare customerId varchar(40);
	declare houseId varchar(40);
	declare executorId varchar(36);
	declare executorOrg varchar(36);
	declare executName varchar(36);
	declare createId varchar(36);
	#查询销售机会id
	declare collectorOrg varchar(36);
	#获取需要建任务的客户信息的游标
	declare add_task cursor for 
		SELECT
				CUSTOMER_ID, HOUSE_ID, GUIDE_ID, GUIDE_ORG_ID, GUIDE_NAME, CREATOR_ID, CREATOR_ORGANIZATION_ID
		FROM
			CUST_OPPORTUNITY a
		WHERE
			NOT EXISTS (SELECT OPPORTUNITY_ID FROM ORD_BRAND_ORDER b WHERE a.ID = b.OPPORTUNITY_ID)
		AND CREATOR_ID IS NOT NULL
		AND CREATOR_NAME IS NOT NULL
		AND CREATOR_ORGANIZATION_ID IS NOT NULL
		AND GUIDE_ID IS NOT NULL
		AND GUIDE_ID != "999999999"
		AND GUIDE_NAME IS NOT NULL
		AND GUIDE_ORG_ID IS NOT NULL
		AND DESIGNER_ID IS NULL
		AND DESIGNER_NAME IS NULL
		AND DESIGNER_ORG_ID IS NULL
		AND MEASURE_DATE IS NULL
		AND VALID = TRUE
		GROUP BY CUSTOMER_ID, HOUSE_ID, GUIDE_ID, GUIDE_ORG_ID, GUIDE_NAME, CREATOR_ID, CREATOR_ORGANIZATION_ID;
	#结束游标的标识
	declare continue handler for not found set done = 1;
	#打开游标
	open add_task;
	#开始循环
	repeat
	#拿到列的数据
	fetch add_task into customerId, houseId, executorId, executorOrg, executName, createId, collectorOrg;
	#进行数据操作
	if not done then #防止重复数据
	#一、插入任务
		#生成任务的uuid
		select replace(uuid(), '-', '') into taskId; 
		insert into TASK 
			(ID, CUSTOMER_ID, ENTITY_ID, TYPE, STATUS, EXECUTOR_ID, EXECUTOR_NAME, EXECUTE_TIME, EXECUTOR_ORG, CREATE_ID, CREATE_TIME) 
		values 
			(taskId, customerId, houseId, "FOLLOW", "WAIT", executorId, executName, now(), executorOrg, createId, now());
	#二、添加任务销售机会
		insert into TASK_OPPORTUNITY (TASK_ID, OPPORTUNITY_ID, STATUS)
			SELECT
					concat(taskId) as TASK_ID, ID as OPPORTUNITY_ID, concat("VALID") as STATUS
			FROM
				CUST_OPPORTUNITY
			WHERE
				CREATOR_ID = createId
			AND CREATOR_ORGANIZATION_ID = collectorOrg
			AND CREATOR_NAME IS NOT NULL
			AND GUIDE_ID = executorId
			AND GUIDE_NAME = executName
			AND GUIDE_ORG_ID = executorOrg
			AND DESIGNER_ID IS NULL
			AND DESIGNER_NAME IS NULL
			AND DESIGNER_ORG_ID IS NULL
			AND VALID = TRUE
			AND CUSTOMER_ID = customerId
			AND HOUSE_ID = houseId;
	end if;
	#拿到游标结束标识，结束本次
	until done end repeat;
	#关闭游标
	close add_task;
end;

