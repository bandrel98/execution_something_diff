create
    definer = hemp@`%` procedure mv_CHANNEL_COOPERATOR_LEVEL()
BEGIN
TRUNCATE TABLE dspdb.`CHANNEL_COOPERATOR_LEVEL`;
-- 以索菲亚的等级为准
INSERT INTO dspdb.`CHANNEL_COOPERATOR_LEVEL`
SELECT
   a.VIP_ID
  ,a.GRADE
  ,a.CREDITS
  ,a.TOPCASHBACK_RATIO
  ,a.NOTE
  ,a.ORDER_SUM
  ,a.ORDER_NUM
  ,'010'
  ,a.CREATE_BY
  ,a.CREATE_TIME
  ,'485bf350bb7d4b5b8fcb583f5c50c036'
  ,'北京赛益世装饰材料有限公司'
  ,IFNULL(b.new_id,'999999999')
  ,a.LAST_UPDATE_TIME
FROM sogaldb.DMS_MEMBER_BASIS a
LEFT JOIN (SELECT * FROM max_test.map_emp GROUP BY old_mobile) b ON a.LAST_UPDATE_BY=b.old_mobile;
    END;

