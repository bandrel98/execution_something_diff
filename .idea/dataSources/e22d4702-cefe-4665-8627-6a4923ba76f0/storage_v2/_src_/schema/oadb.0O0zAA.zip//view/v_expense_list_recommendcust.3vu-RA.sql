create view v_expense_list_recommendcust as
select `s`.`ID`                                                            AS `summaryId`,
       `m`.`ID`                                                            AS `formId`,
       `m`.`field0003`                                                     AS `processCode`,
       '推荐官客户优惠'                                                           AS `processTypeName`,
       'recommendcust'                                                     AS `processType`,
       '出款'                                                                AS `paymentType`,
       (case `m`.`finishedflag` when 0 then '未结束' else '已结束' end)          AS `processStatus`,
       `reg`.`NAME`                                                        AS `applicant`,
       `dspmem`.`thirdpartId`                                              AS `applicantId`,
       `unit`.`NAME`                                                       AS `applicantDept`,
       `dspdept`.`thirdId`                                                 AS `applicantDeptId`,
       trim(`m`.`field0013`)                                               AS `paymentAmount`,
       `m`.`field0024`                                                     AS `remarks`,
       ''                                                                  AS `brand`,
       `m`.`field0005`                                                     AS `applicantDate`,
       `det`.`field0030`                                                   AS `bankConfirmDate`,
       `mem`.`NAME`                                                        AS `cashier2`,
       `ca`.`COMPLETE_TIME`                                                AS `cashier2ApprovalTime`,
       (case `m`.`finishedflag` when 1 then `m`.`modify_date` else '' end) AS `processEndTime`,
       ''                                                                  AS `paymentContract`
from ((((((((`oadb`.`formmain_1101` `m` left join (select distinct `oadb`.`formson_1103`.`formmain_id` AS `formmain_id`,
                                                                   `oadb`.`formson_1103`.`field0030`   AS `field0030`
                                                   from `oadb`.`formson_1103`) `det` on ((`det`.`formmain_id` = `m`.`ID`))) left join `oadb`.`org_unit` `unit` on ((`unit`.`ID` = `m`.`field0002`))) left join `oadb`.`org_member` `reg` on ((`reg`.`ID` = `m`.`field0001`))) left join `oadb`.`col_summary` `s` on (((`s`.`FORM_RECORDID` = `m`.`ID`) and (`s`.`CASE_ID` is not null)))) left join `oadb`.`ctp_affair` `ca` on ((
        (`ca`.`OBJECT_ID` = `s`.`ID`) and
        (`ca`.`ACTIVITY_ID` = 156327049952421)))) left join `oadb`.`org_member` `mem` on ((`mem`.`ID` = `ca`.`MEMBER_ID`))) left join `oadb`.`pro_member_extend` `dspmem` on ((`dspmem`.`memberId` = `m`.`field0001`)))
         left join `oadb`.`pro_dept_extend` `dspdept` on ((`dspdept`.`oaDeptId` = `m`.`field0002`)))
where ((`det`.`field0030` is not null) and (`det`.`field0030` > '2021-03-31'))
order by `det`.`field0030` desc;

