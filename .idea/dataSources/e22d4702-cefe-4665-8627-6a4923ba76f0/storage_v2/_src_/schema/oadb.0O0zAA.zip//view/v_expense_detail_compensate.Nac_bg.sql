create view v_expense_detail_compensate as
select `det`.`formmain_id`  AS `formId`,
       `det`.`ID`           AS `id`,
       `det`.`field0093`    AS `expenseDeptId`,
       `unit`.`NAME`        AS `expenseDept`,
       `budget`.`ID`        AS `budgetId`,
       `budget`.`field0009` AS `budget`,
       `det`.`field0044`    AS `expenseAmount`,
       `m`.`field0063`      AS `processCode`,
       ''                   AS `remarks`
from ((((`oadb`.`formson_0476` `det` join `oadb`.`formmain_0472` `m` on ((`det`.`formmain_id` = `m`.`ID`))) left join `oadb`.`org_unit` `unit` on ((`unit`.`ID` = `det`.`field0093`))) left join `oadb`.`pro_dept_extend` `dspdept` on ((`dspdept`.`oaDeptId` = `det`.`field0093`)))
         left join `oadb`.`formmain_1259` `budget` on ((`budget`.`field0007` = `det`.`field0094`)))
where (`m`.`finishedflag` <> 3);

