create view v_expense_detail_recommendcust as
select `m`.`ID`                                 AS `formId`,
       `m`.`ID`                                 AS `id`,
       `dspdept`.`thirdId`                      AS `expenseDeptId`,
       ifnull(`unit`.`NAME`, `det`.`field0041`) AS `expenseDept`,
       `budget`.`ID`                            AS `budgetId`,
       `budget`.`field0009`                     AS `budget`,
       `m`.`field0013`                          AS `expenseAmount`,
       `m`.`field0003`                          AS `processCode`,
       ''                                       AS `remarks`
from (((((`oadb`.`formmain_1101` `m` left join `oadb`.`formson_1102` `det` on ((`det`.`formmain_id` = `m`.`ID`))) left join `oadb`.`org_unit` `unit` on ((`unit`.`ID` = `det`.`field0041`))) left join `oadb`.`org_unit` `deptids` on ((
        (`deptids`.`NAME` = ifnull(`unit`.`NAME`, `det`.`field0041`)) and
        (`deptids`.`IS_DELETED` = 0)))) left join `oadb`.`pro_dept_extend` `dspdept` on ((`dspdept`.`oaDeptId` = `deptids`.`ID`)))
         left join `oadb`.`formmain_1259` `budget` on ((`budget`.`field0007` = `det`.`field0056`)))
where (`m`.`finishedflag` <> 3);

