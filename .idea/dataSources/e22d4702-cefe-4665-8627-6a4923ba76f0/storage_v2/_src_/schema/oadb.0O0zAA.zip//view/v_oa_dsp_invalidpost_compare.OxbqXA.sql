create view v_oa_dsp_invalidpost_compare as
select `post`.`NAME`           AS `组织名称`,
       `post`.`ID`             AS `组织id`,
       `ext`.`thirdpartId`     AS `dsp组织id`,
       `post`.`ID`             AS `ID`,
       `post`.`NAME`           AS `NAME`,
       `post`.`CODE`           AS `CODE`,
       `post`.`IS_ENABLE`      AS `IS_ENABLE`,
       `post`.`TYPE`           AS `TYPE`,
       `post`.`SORT_ID`        AS `SORT_ID`,
       `post`.`CREATE_TIME`    AS `CREATE_TIME`,
       `post`.`UPDATE_TIME`    AS `UPDATE_TIME`,
       `post`.`DESCRIPTION`    AS `DESCRIPTION`,
       `post`.`ORG_ACCOUNT_ID` AS `ORG_ACCOUNT_ID`,
       `post`.`IS_DELETED`     AS `IS_DELETED`,
       `post`.`STATUS`         AS `STATUS`,
       `post`.`EXTERNAL_TYPE`  AS `EXTERNAL_TYPE`
from ((`oadb`.`org_post` `post` left join `oadb`.`pro_post_extend` `ext` on ((`ext`.`postId` = `post`.`ID`)))
         left join `test`.`dealer_employee` `dspmem` on ((`dspmem`.`ID` = `ext`.`thirdpartId`)))
where ((`post`.`IS_DELETED` = 1) and (`post`.`IS_ENABLE` = 0) and (not (`ext`.`thirdpartId` in
                                                                        (select `dpos`.`ID` AS `DSP组织机构主键`
                                                                         from `test`.`dealer_position` `dpos`
                                                                         where (`dpos`.`VALID` = 0)))));

