create
    definer = oauser@`%` procedure proc_nextserialnumber(IN sid bigint, IN readonly int, OUT nextval bigint)
BEGIN
		DECLARE svalue,rulreset,minval,todbval,maxval bigint;
		DECLARE digitnum,currentyear,currentmonth,currentday,markyear,markmonth,markday,_err int;
		DECLARE scurrentmarkdate,currentdate datetime;
		DECLARE CONTINUE  HANDLER FOR SQLEXCEPTION,NOT FOUND set _err=1;
		start transaction;
		select `value`, `current_mark_date`,`rule_reset`,`min_value`,`digit` into svalue, scurrentmarkdate,rulreset,minval,digitnum from form_serial_number where id=sid for update;
		if(svalue is null)
			then 
				set svalue=1;
		end if;
		set nextval = svalue;
		set currentdate = now();
		set currentyear = year(currentdate);
		set currentmonth = month(currentdate);
		set currentday = DAY(currentdate);
		set markyear = year(scurrentmarkdate);
		set markmonth = month(scurrentmarkdate);
		set markday = DAY(scurrentmarkdate);
		
		if (((rulreset=1) and (currentyear!=markyear)) or ((rulreset=2) and (currentyear!=markyear or currentmonth!=markmonth)) or ((rulreset=3) and (currentyear!=markyear or currentmonth!=markmonth or currentday!=markday)) )
		then
			if(minval is not null)
				THEN
				set nextval=minval;
			else
				set nextval=1;
			end if;	
		end if;

		if(readonly=0)
			THEN

			set maxval=power(10,digitnum);
			if(nextval>=(maxval-1))
				THEN
					if(minval is null)
						THEN
						set todbval=1;
					else
						set todbval=minval;
					end if;	
			else
					set todbval=nextval+1;
			end if;
			update form_serial_number set `value`=todbval,`current_mark_date`=currentdate where id=sid;
		end if;
		if(_err=1)
			then
				rollback;
			else
				commit;
		end if;
END;

