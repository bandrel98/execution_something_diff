create view v_expense_detail_rentpayment as
select `m`.`formmain_id`                                                                           AS `formId`,
       `m`.`ID`                                                                                    AS `id`,
       `dspdept`.`thirdId`                                                                         AS `expenseDeptId`,
       `unit`.`NAME`                                                                               AS `expenseDept`,
       ''                                                                                          AS `budgetId`,
       ''                                                                                          AS `budget`,
       (case when isnull(`m`.`field0084`) then 0 else replace(trim(`m`.`field0043`), '：', '') end) AS `expenseAmount`,
       `fm`.`field0001`                                                                            AS `processCode`
from (((`oadb`.`formson_0965` `m` join `oadb`.`formmain_0961` `fm` on ((`m`.`formmain_id` = `fm`.`ID`))) left join `oadb`.`org_unit` `unit` on ((`unit`.`ID` = `m`.`field0038`)))
         left join `oadb`.`pro_dept_extend` `dspdept` on ((`dspdept`.`oaDeptId` = `m`.`field0038`)))
where (`fm`.`finishedflag` = 1);

