create view v_oa_dsp_unit_compare as
select `unit`.`NAME`           AS `组织名称`,
       `unit`.`ID`             AS `组织id`,
       `ext`.`thirdId`         AS `dsp组织id`,
       `unit`.`ID`             AS `ID`,
       `unit`.`NAME`           AS `NAME`,
       `unit`.`SECOND_NAME`    AS `SECOND_NAME`,
       `unit`.`CODE`           AS `CODE`,
       `unit`.`SHORT_NAME`     AS `SHORT_NAME`,
       `unit`.`TYPE`           AS `TYPE`,
       `unit`.`IS_GROUP`       AS `IS_GROUP`,
       `unit`.`PATH`           AS `PATH`,
       `unit`.`IS_INTERNAL`    AS `IS_INTERNAL`,
       `unit`.`SORT_ID`        AS `SORT_ID`,
       `unit`.`IS_ENABLE`      AS `IS_ENABLE`,
       `unit`.`IS_DELETED`     AS `IS_DELETED`,
       `unit`.`STATUS`         AS `STATUS`,
       `unit`.`LEVEL_SCOPE`    AS `LEVEL_SCOPE`,
       `unit`.`ORG_ACCOUNT_ID` AS `ORG_ACCOUNT_ID`,
       `unit`.`CREATE_TIME`    AS `CREATE_TIME`,
       `unit`.`UPDATE_TIME`    AS `UPDATE_TIME`,
       `unit`.`DESCRIPTION`    AS `DESCRIPTION`,
       `unit`.`EXT_ATTR_1`     AS `EXT_ATTR_1`,
       `unit`.`EXT_ATTR_2`     AS `EXT_ATTR_2`,
       `unit`.`EXT_ATTR_3`     AS `EXT_ATTR_3`,
       `unit`.`EXT_ATTR_4`     AS `EXT_ATTR_4`,
       `unit`.`EXT_ATTR_5`     AS `EXT_ATTR_5`,
       `unit`.`EXT_ATTR_6`     AS `EXT_ATTR_6`,
       `unit`.`EXT_ATTR_7`     AS `EXT_ATTR_7`,
       `unit`.`EXT_ATTR_8`     AS `EXT_ATTR_8`,
       `unit`.`EXT_ATTR_9`     AS `EXT_ATTR_9`,
       `unit`.`EXT_ATTR_10`    AS `EXT_ATTR_10`,
       `unit`.`EXT_ATTR_11`    AS `EXT_ATTR_11`,
       `unit`.`EXT_ATTR_12`    AS `EXT_ATTR_12`,
       `unit`.`EXT_ATTR_13`    AS `EXT_ATTR_13`,
       `unit`.`EXT_ATTR_14`    AS `EXT_ATTR_14`,
       `unit`.`EXT_ATTR_15`    AS `EXT_ATTR_15`,
       `unit`.`EXTERNAL_TYPE`  AS `EXTERNAL_TYPE`
from ((`oadb`.`org_unit` `unit` left join `oadb`.`pro_dept_extend` `ext` on ((`ext`.`oaDeptId` = `unit`.`ID`)))
         left join `test`.`dealer_organization` `dspmem` on ((`dspmem`.`ID` = `ext`.`thirdId`)))
where ((`unit`.`IS_DELETED` = 0) and (`unit`.`IS_ENABLE` = 1) and (not (`ext`.`thirdId` in
                                                                        (select `org`.`ID` AS `DSP组织机构主键`
                                                                         from `test`.`dealer_organization` `org`
                                                                         where (`org`.`VALID` = 1)))));

