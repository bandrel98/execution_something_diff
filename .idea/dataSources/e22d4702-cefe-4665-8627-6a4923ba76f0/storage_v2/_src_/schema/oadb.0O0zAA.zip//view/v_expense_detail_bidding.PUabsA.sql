create view v_expense_detail_bidding as
select `m`.`ID`                                                                                                 AS `formId`,
       `m`.`ID`                                                                                                 AS `id`,
       `dspdept`.`thirdId`                                                                                      AS `expenseDeptId`,
       `unit`.`NAME`                                                                                            AS `expenseDept`,
       ''                                                                                                       AS `budgetId`,
       ''                                                                                                       AS `budget`,
       (case
            when isnull(`det`.`field0024`) then 0
            else replace((trim(`det`.`field0024`) * -(1)), '：', '') end)                                        AS `expenseAmount`,
       `det`.`field0001`                                                                                        AS `processCode`
from (((`oadb`.`formmain_0697` `m` left join `oadb`.`formmain_0694` `det` on ((`det`.`field0001` = `m`.`field0001`))) left join `oadb`.`org_unit` `unit` on ((`unit`.`ID` = `det`.`field0033`)))
         left join `oadb`.`pro_dept_extend` `dspdept` on ((`dspdept`.`oaDeptId` = `det`.`field0033`)))
where (`m`.`finishedflag` = 1);

