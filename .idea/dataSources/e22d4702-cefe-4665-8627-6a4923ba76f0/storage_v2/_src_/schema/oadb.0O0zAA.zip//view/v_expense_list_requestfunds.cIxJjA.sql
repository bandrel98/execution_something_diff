create view v_expense_list_requestfunds as
select `s`.`ID`                                                                                                  AS `summaryId`,
       `m`.`ID`                                                                                                  AS `formId`,
       `m`.`field0085`                                                                                           AS `processCode`,
       '请款'                                                                                                      AS `processTypeName`,
       'requestfunds'                                                                                            AS `processType`,
       (case `process`.`SHOWVALUE`
            when '出纳审批' then '出款'
            else `process`.`SHOWVALUE` end)                                                                      AS `paymentType`,
       (case `m`.`finishedflag` when 0 then '未结束' else '已结束' end)                                                AS `processStatus`,
       `reg`.`NAME`                                                                                              AS `applicant`,
       `dspmem`.`thirdpartId`                                                                                    AS `applicantId`,
       `unit`.`NAME`                                                                                             AS `applicantDept`,
       `dspdept`.`thirdId`                                                                                       AS `applicantDeptId`,
       trim(`det`.`field0053`)                                                                                   AS `paymentAmount`,
       `m`.`field0093`                                                                                           AS `remarks`,
       `pp`.`SHOWVALUE`                                                                                          AS `brand`,
       `m`.`field0019`                                                                                           AS `applicantDate`,
       `det`.`field0052`                                                                                         AS `bankConfirmDate`,
       `mem`.`NAME`                                                                                              AS `cashier2`,
       `ca`.`COMPLETE_TIME`                                                                                      AS `cashier2ApprovalTime`,
       (case `m`.`finishedflag` when 1 then `m`.`modify_date` else '' end)                                       AS `processEndTime`,
       (case `m`.`field0027`
            when '413678347345940297' then '0'
            when '3111180113656367999' then '1'
            else '' end)                                                                                         AS `paymentContract`
from ((((((((((`oadb`.`formmain_0431` `m` join `oadb`.`formson_0434` `det` on ((`det`.`formmain_id` = `m`.`ID`))) left join `oadb`.`org_unit` `unit` on ((`unit`.`ID` = `m`.`field0015`))) left join `oadb`.`org_member` `reg` on ((`reg`.`ID` = `m`.`field0013`))) left join `oadb`.`col_summary` `s` on (((`s`.`FORM_RECORDID` = `m`.`ID`) and (`s`.`CASE_ID` is not null)))) left join (select `oadb`.`ctp_affair`.`OBJECT_ID`     AS `OBJECT_ID`,
                                                                                                                                                                                                                                                                                                                                                                                                  `oadb`.`ctp_affair`.`MEMBER_ID`     AS `MEMBER_ID`,
                                                                                                                                                                                                                                                                                                                                                                                                  `oadb`.`ctp_affair`.`COMPLETE_TIME` AS `COMPLETE_TIME`
                                                                                                                                                                                                                                                                                                                                                                                           from `oadb`.`ctp_affair`
                                                                                                                                                                                                                                                                                                                                                                                           where (`oadb`.`ctp_affair`.`ACTIVITY_ID` = 155729620780735)
                                                                                                                                                                                                                                                                                                                                                                                           group by `oadb`.`ctp_affair`.`OBJECT_ID`
                                                                                                                                                                                                                                                                                                                                                                                           order by `oadb`.`ctp_affair`.`UPDATE_DATE` desc) `ca` on ((`ca`.`OBJECT_ID` = `s`.`ID`))) left join `oadb`.`org_member` `mem` on ((`mem`.`ID` = `ca`.`MEMBER_ID`))) left join `oadb`.`ctp_enum_item` `pp` on ((`pp`.`ID` = `m`.`field0022`))) left join `oadb`.`ctp_enum_item` `process` on ((`process`.`ID` = `m`.`field0099`))) left join `oadb`.`pro_member_extend` `dspmem` on ((`dspmem`.`memberId` = `m`.`field0013`)))
         left join `oadb`.`pro_dept_extend` `dspdept` on ((`dspdept`.`oaDeptId` = `m`.`field0015`)))
where ((`det`.`field0052` is not null) and (`det`.`field0052` > '2021-03-31'))
order by `det`.`field0052` desc;

