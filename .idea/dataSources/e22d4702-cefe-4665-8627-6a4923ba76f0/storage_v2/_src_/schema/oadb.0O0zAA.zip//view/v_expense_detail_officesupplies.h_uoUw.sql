create view v_expense_detail_officesupplies as
select `m`.`ID`            AS `formId`,
       `m`.`ID`            AS `id`,
       `dspdept`.`thirdId` AS `expenseDeptId`,
       `unit`.`NAME`       AS `expenseDept`,
       ''                  AS `budgetId`,
       ''                  AS `budget`,
       `det`.`field0062`   AS `expenseAmount`,
       `m`.`field0029`     AS `processCode`
from (((`oadb`.`formmain_0268` `m` left join `oadb`.`formson_0269` `det` on ((`det`.`formmain_id` = `m`.`ID`))) left join `oadb`.`org_unit` `unit` on ((`unit`.`ID` = `det`.`field0050`)))
         left join `oadb`.`pro_dept_extend` `dspdept` on ((`dspdept`.`oaDeptId` = `det`.`field0050`)))
where (`m`.`finishedflag` = 1);

