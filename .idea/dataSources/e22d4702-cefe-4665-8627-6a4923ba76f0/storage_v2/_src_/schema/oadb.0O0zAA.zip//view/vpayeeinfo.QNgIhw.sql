create view vpayeeinfo as
select `a`.`type`              AS `type`,
       `a`.`payeeName`         AS `payeeName`,
       `a`.`depositBankId`     AS `depositBankId`,
       `a`.`depositBank`       AS `depositBank`,
       `a`.`branchDepositBank` AS `branchDepositBank`,
       `a`.`depositAccont`     AS `depositAccont`,
       `a`.`dept`              AS `dept`,
       `a`.`creator`           AS `creator`,
       `a`.`userId`            AS `userId`,
       `a`.`ts`                AS `ts`
from (select `lx`.`SHOWVALUE`       AS `type`,
             `fm0563`.`field0024`   AS `payeeName`,
             `fm0563`.`field0025`   AS `depositBankId`,
             `yh`.`SHOWVALUE`       AS `depositBank`,
             `fm0563`.`field0027`   AS `branchDepositBank`,
             `fm0563`.`field0026`   AS `depositAccont`,
             `unit`.`NAME`          AS `dept`,
             `mem`.`NAME`           AS `creator`,
             `fm0563`.`field0030`   AS `userId`,
             `fm0563`.`modify_date` AS `ts`
      from ((((((`oadb`.`formmain_0563` `fm0563` left join (select distinct `oadb`.`formson_1430`.`field0001` AS `field0001`
                                                            from `oadb`.`formson_1430`) `bmqx` on ((`bmqx`.`field0001` = `fm0563`.`field0029`))) left join `oadb`.`org_unit` `unit` on ((`unit`.`ID` = `fm0563`.`field0029`))) left join `oadb`.`org_member` `mem` on ((`mem`.`ID` = `fm0563`.`field0030`))) left join (select `oadb`.`formson_1430`.`field0001` AS `field0001`,
                                                                                                                                                                                                                                                                                                                               `oadb`.`formson_1430`.`field0005` AS `field0005`
                                                                                                                                                                                                                                                                                                                        from `oadb`.`formson_1430`) `qx` on ((
              (`qx`.`field0005` = `fm0563`.`field0030`) and
              (`bmqx`.`field0001` = `fm0563`.`field0029`)))) left join `oadb`.`ctp_enum_item` `lx` on ((`lx`.`ID` = `fm0563`.`field0028`)))
               left join `oadb`.`ctp_enum_item` `yh` on ((`yh`.`ID` = `fm0563`.`field0025`)))
      union
      select distinct `lx`.`SHOWVALUE`       AS `type`,
                      `fm0563`.`field0024`   AS `payeeName`,
                      `fm0563`.`field0025`   AS `depositBankId`,
                      `yh`.`SHOWVALUE`       AS `depositBank`,
                      `fm0563`.`field0027`   AS `branchDepositBank`,
                      `fm0563`.`field0026`   AS `depositAccont`,
                      `unit`.`NAME`          AS `dept`,
                      `mem`.`NAME`           AS `creator`,
                      `bmqx`.`field0005`     AS `userId`,
                      `fm0563`.`modify_date` AS `ts`
      from (((((`oadb`.`formmain_0563` `fm0563` left join (select `oadb`.`formson_1430`.`field0001` AS `field0001`,
                                                                  `oadb`.`formson_1430`.`field0005` AS `field0005`
                                                           from `oadb`.`formson_1430`) `bmqx` on ((`bmqx`.`field0001` = `fm0563`.`field0029`))) left join `oadb`.`org_unit` `unit` on ((`unit`.`ID` = `fm0563`.`field0029`))) left join `oadb`.`org_member` `mem` on ((
              (`mem`.`ID` = `fm0563`.`field0030`) and
              (`bmqx`.`field0001` = `fm0563`.`field0029`)))) left join `oadb`.`ctp_enum_item` `lx` on ((`lx`.`ID` = `fm0563`.`field0028`)))
               left join `oadb`.`ctp_enum_item` `yh` on ((`yh`.`ID` = `fm0563`.`field0025`)))
      where (`mem`.`NAME` is not null)) `a`
order by `a`.`dept`, `a`.`creator`, `a`.`ts` desc;

