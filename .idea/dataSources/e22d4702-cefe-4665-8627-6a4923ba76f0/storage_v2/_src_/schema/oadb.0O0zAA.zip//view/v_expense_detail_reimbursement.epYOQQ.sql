create view v_expense_detail_reimbursement as
select `det`.`formmain_id`                                                                             AS `formId`,
       `det`.`ID`                                                                                      AS `id`,
       `dspdept`.`thirdId`                                                                             AS `expenseDeptId`,
       `unit`.`NAME`                                                                                   AS `expenseDept`,
       `budget`.`ID`                                                                                   AS `budgetId`,
       `budget`.`field0009`                                                                            AS `budget`,
       (case
            when isnull(`det`.`field0040`) then 0
            else replace(trim(`det`.`field0040`), '：', '') end)                                        AS `expenseAmount`,
       `m`.`field0082`                                                                                 AS `processCode`,
       `det`.`field0036`                                                                               AS `remarks`
from ((((`oadb`.`formson_0447` `det` join `oadb`.`formmain_0445` `m` on ((`det`.`formmain_id` = `m`.`ID`))) left join `oadb`.`org_unit` `unit` on ((`unit`.`ID` = `det`.`field0037`))) left join `oadb`.`pro_dept_extend` `dspdept` on ((`dspdept`.`oaDeptId` = `det`.`field0037`)))
         left join `oadb`.`formmain_1259` `budget` on ((`budget`.`field0007` = `det`.`field0111`)))
where (`m`.`finishedflag` <> 3);

