create view v_expense_list_bidding as
select `s`.`ID`                                                            AS `summaryId`,
       `m`.`ID`                                                            AS `formId`,
       `m`.`field0001`                                                     AS `processCode`,
       '竞拍'                                                                AS `processTypeName`,
       'bidding'                                                           AS `processType`,
       '不出款'                                                               AS `paymentType`,
       (case `m`.`finishedflag` when 0 then '未结束' else '已结束' end)          AS `processStatus`,
       `reg`.`NAME`                                                        AS `applicant`,
       `dspmem`.`thirdpartId`                                              AS `applicantId`,
       `unit`.`NAME`                                                       AS `applicantDept`,
       `dspdept`.`thirdId`                                                 AS `applicantDeptId`,
       (trim(`m`.`field0024`) * -(1))                                      AS `paymentAmount`,
       ''                                                                  AS `remarks`,
       ''                                                                  AS `brand`,
       `m`.`field0017`                                                     AS `applicantDate`,
       `m`.`field0040`                                                     AS `bankConfirmDate`,
       ''                                                                  AS `cashier2`,
       ''                                                                  AS `cashier2ApprovalTime`,
       (case `m`.`finishedflag` when 1 then `m`.`modify_date` else '' end) AS `processEndTime`,
       ''                                                                  AS `paymentContract`
from ((((((`oadb`.`formmain_0697` `m` join `oadb`.`formmain_0694` `det` on ((`det`.`field0001` = `m`.`field0001`))) left join `oadb`.`org_unit` `unit` on ((`unit`.`ID` = `m`.`field0029`))) left join `oadb`.`org_member` `reg` on ((`reg`.`ID` = `det`.`field0028`))) left join `oadb`.`col_summary` `s` on (((`s`.`FORM_RECORDID` = `m`.`ID`) and (`s`.`CASE_ID` is not null)))) left join `oadb`.`pro_member_extend` `dspmem` on ((`dspmem`.`memberId` = `det`.`field0028`)))
         left join `oadb`.`pro_dept_extend` `dspdept` on ((`dspdept`.`oaDeptId` = `m`.`field0029`)))
where ((`m`.`finishedflag` = 1) and (`m`.`modify_date` > '2021-03-31 23:59:59'))
order by `m`.`modify_date` desc;

